package os.kei.ui.page.main.ba

import android.content.Context
import os.kei.R
import os.kei.core.ext.showToast
import os.kei.core.intent.SafeExternalIntents
import os.kei.ui.page.main.ba.support.BA_AP_LIMIT_MAX
import os.kei.ui.page.main.ba.support.BA_AP_MAX
import os.kei.ui.page.main.ba.support.BA_AP_REGEN_INTERVAL_MS
import os.kei.ui.page.main.ba.support.BA_CAFE_HOURLY_INTERVAL_MS
import os.kei.ui.page.main.ba.support.BA_HEADPAT_COOLDOWN_MS
import os.kei.ui.page.main.ba.support.BA_INVITE_COOLDOWN_MS
import os.kei.ui.page.main.ba.support.cafeHourlyGain
import os.kei.ui.page.main.ba.support.cafeStorageCap
import os.kei.ui.page.main.ba.support.calculateInviteTicketAvailableMs
import os.kei.ui.page.main.ba.support.calculateNextHeadpatAvailableMs
import os.kei.ui.page.main.ba.support.currentCafeStudentRefreshSlotMs
import os.kei.ui.page.main.ba.support.floorToHourMs
import os.kei.ui.page.main.ba.support.fractionalApPart
import os.kei.ui.page.main.ba.support.nextCafeStudentRefreshMs
import os.kei.ui.page.main.ba.support.normalizeAp
import kotlin.math.roundToInt

internal fun openBaExternalLink(
    context: Context,
    url: String,
    failureMessage: String = context.getString(R.string.ba_error_open_activity_link),
) {
    if (!SafeExternalIntents.startBrowsableUrl(context, url, newTask = true)) {
        context.showToast(failureMessage)
    }
}

internal fun applyBaCurrentApUpdate(
    currentAp: Double,
    newValue: Int,
    nowMs: Long = System.currentTimeMillis(),
): Pair<Double, Long> {
    val integerPart = newValue.coerceIn(0, BA_AP_MAX)
    val fractionPart = fractionalApPart(currentAp)
    val next = normalizeAp(integerPart.toDouble() + fractionPart)
    return next to nowMs
}

internal fun applyBaCurrentApDelta(
    currentAp: Double,
    delta: Double,
    nowMs: Long = System.currentTimeMillis(),
): Pair<Double, Long>? {
    if (delta <= 0.0) return null
    return normalizeAp(currentAp + delta) to nowMs
}

internal fun coerceBaApLimit(newLimit: Int): Int = newLimit.coerceIn(0, BA_AP_LIMIT_MAX)

internal fun applyBaApRegenTick(
    apLimit: Int,
    apCurrent: Double,
    apRegenBaseMs: Long,
    nowMs: Long = System.currentTimeMillis(),
): Pair<Double, Long> {
    val limit = apLimit.coerceIn(0, BA_AP_LIMIT_MAX)
    if (limit <= 0) return apCurrent.coerceAtLeast(0.0) to nowMs

    val current = apCurrent.coerceAtLeast(0.0)
    val ensuredBase = if (apRegenBaseMs <= 0L) nowMs else apRegenBaseMs
    if (current >= limit.toDouble()) return current to ensuredBase

    val elapsed = (nowMs - ensuredBase).coerceAtLeast(0L)
    val gained = (elapsed / BA_AP_REGEN_INTERVAL_MS).toInt()
    if (gained <= 0) return current to ensuredBase

    val pointsUntilStop =
        kotlin.math
            .ceil(limit.toDouble() - current)
            .toInt()
            .coerceAtLeast(0)
    val pointsApplied = gained.coerceAtMost(pointsUntilStop)
    if (pointsApplied <= 0) return current to ensuredBase

    val nextAp = normalizeAp(current + pointsApplied.toDouble())
    val nextBase =
        if (nextAp >= limit.toDouble()) {
            nowMs
        } else {
            ensuredBase + pointsApplied * BA_AP_REGEN_INTERVAL_MS
        }
    return nextAp to nextBase
}

internal fun applyBaCafeStorageTick(
    cafeStoredAp: Double,
    cafeLevel: Int,
    cafeLastHourMs: Long,
    nowMs: Long = System.currentTimeMillis(),
): Pair<Double, Long> {
    val currentHour = floorToHourMs(nowMs)
    val baseHour = if (cafeLastHourMs <= 0L || cafeLastHourMs > currentHour) currentHour else cafeLastHourMs
    if (currentHour <= baseHour) return cafeStoredAp to baseHour
    val hoursPassed = ((currentHour - baseHour) / BA_CAFE_HOURLY_INTERVAL_MS).toInt()
    if (hoursPassed <= 0) return cafeStoredAp to baseHour
    val gained = hoursPassed * cafeHourlyGain(cafeLevel)
    val cap = cafeStorageCap(cafeLevel)
    return normalizeAp((cafeStoredAp + gained).coerceAtMost(cap)) to currentHour
}

internal fun applyBaCafeStoredApUpdate(
    newValue: Double,
    cafeLevel: Int,
    nowMs: Long = System.currentTimeMillis(),
): Pair<Double, Long> {
    val cap = cafeStorageCap(cafeLevel)
    val next = normalizeAp(newValue.coerceIn(0.0, cap))
    return next to floorToHourMs(nowMs)
}

internal fun applyBaCafeClaim(cafeStoredAp: Double): Double = normalizeAp(cafeStoredAp)

internal fun applyBaCafeDebugGain(
    cafeStoredAp: Double,
    cafeLevel: Int,
): Pair<Double, Int> {
    val gained = normalizeAp(cafeHourlyGain(cafeLevel) * 3.0)
    val cap = cafeStorageCap(cafeLevel)
    val next = normalizeAp((cafeStoredAp + gained).coerceAtMost(cap))
    return next to gained.roundToInt()
}

internal fun consumeBaHeadpat(
    coffeeHeadpatMs: Long,
    serverIndex: Int,
    nowMs: Long = System.currentTimeMillis(),
): Long? {
    val availableAt = calculateNextHeadpatAvailableMs(coffeeHeadpatMs, serverIndex)
    if (coffeeHeadpatMs > 0L && availableAt > nowMs) return null
    return nowMs
}

internal fun consumeBaInviteTicket(
    usedMs: Long,
    nowMs: Long = System.currentTimeMillis(),
): Long? {
    val availableAt = calculateInviteTicketAvailableMs(usedMs)
    if (usedMs > 0L && availableAt > nowMs) return null
    return nowMs
}

internal fun calculateBaCafeCooldownRemainingMs(
    target: BaCafeCooldownEditTarget,
    coffeeHeadpatMs: Long,
    coffeeInvite1UsedMs: Long,
    coffeeInvite2UsedMs: Long,
    serverIndex: Int,
    nowMs: Long = System.currentTimeMillis(),
): Long {
    val availableAt =
        when (target) {
            BaCafeCooldownEditTarget.Headpat -> calculateNextHeadpatAvailableMs(coffeeHeadpatMs, serverIndex)
            BaCafeCooldownEditTarget.InviteTicket1 -> calculateInviteTicketAvailableMs(coffeeInvite1UsedMs)
            BaCafeCooldownEditTarget.InviteTicket2 -> calculateInviteTicketAvailableMs(coffeeInvite2UsedMs)
        }
    return (availableAt - nowMs).coerceAtLeast(0L)
}

internal fun maxBaCafeCooldownRemainingMs(
    target: BaCafeCooldownEditTarget,
    serverIndex: Int,
    nowMs: Long = System.currentTimeMillis(),
): Long =
    when (target) {
        BaCafeCooldownEditTarget.Headpat ->
            minOf(
                BA_HEADPAT_COOLDOWN_MS,
                nextCafeStudentRefreshMs(nowMs, serverIndex) - nowMs,
            ).coerceAtLeast(0L)

        BaCafeCooldownEditTarget.InviteTicket1,
        BaCafeCooldownEditTarget.InviteTicket2,
        -> BA_INVITE_COOLDOWN_MS
    }

internal fun coerceBaCafeCooldownRemainingMs(
    target: BaCafeCooldownEditTarget,
    remainingMs: Long,
    serverIndex: Int,
    nowMs: Long = System.currentTimeMillis(),
): Long =
    remainingMs.coerceIn(
        minimumValue = 0L,
        maximumValue = maxBaCafeCooldownRemainingMs(
            target = target,
            serverIndex = serverIndex,
            nowMs = nowMs,
        ),
    )

internal fun applyBaHeadpatRemainingCooldown(
    remainingMs: Long,
    serverIndex: Int,
    nowMs: Long = System.currentTimeMillis(),
): Long {
    val clampedRemainingMs =
        coerceBaCafeCooldownRemainingMs(
            target = BaCafeCooldownEditTarget.Headpat,
            remainingMs = remainingMs,
            serverIndex = serverIndex,
            nowMs = nowMs,
        )
    if (clampedRemainingMs <= 0L) return 0L

    val currentSlotMs = currentCafeStudentRefreshSlotMs(nowMs, serverIndex).coerceAtMost(nowMs)
    val earliestActiveRemainingMs =
        (currentSlotMs + BA_HEADPAT_COOLDOWN_MS - nowMs)
            .coerceIn(0L, maxBaCafeCooldownRemainingMs(BaCafeCooldownEditTarget.Headpat, serverIndex, nowMs))
    val representableRemainingMs =
        if (earliestActiveRemainingMs > 0L && clampedRemainingMs < earliestActiveRemainingMs) {
            earliestActiveRemainingMs
        } else {
            clampedRemainingMs
        }
    return (nowMs + representableRemainingMs - BA_HEADPAT_COOLDOWN_MS)
        .coerceIn(currentSlotMs, nowMs)
}

internal fun applyBaInviteTicketRemainingCooldown(
    remainingMs: Long,
    nowMs: Long = System.currentTimeMillis(),
): Long {
    val clampedRemainingMs =
        coerceBaCafeCooldownRemainingMs(
            target = BaCafeCooldownEditTarget.InviteTicket1,
            remainingMs = remainingMs,
            serverIndex = 0,
            nowMs = nowMs,
        )
    if (clampedRemainingMs <= 0L) return 0L
    return (nowMs + clampedRemainingMs - BA_INVITE_COOLDOWN_MS).coerceAtLeast(0L)
}
