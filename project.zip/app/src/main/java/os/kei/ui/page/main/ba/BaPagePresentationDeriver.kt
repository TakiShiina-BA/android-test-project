package os.kei.ui.page.main.ba

import androidx.compose.runtime.Immutable

@Immutable
internal data class BaPagePresentationState(
    val routeState: BaPageRouteState,
    val settingsSheetState: BaSettingsSheetState,
    val notificationSettingsSheetState: BaNotificationSettingsSheetState,
    val savedSettingsDraftState: BaPageSettingsDraftState,
    val savedSettingsSheetState: BaSettingsSheetState,
    val savedNotificationSettingsSheetState: BaNotificationSettingsSheetState,
    val pageContentState: BaPageContentState,
)

internal fun buildBaPagePresentationState(
    officeState: BaOfficeState,
    calendarUiState: BaCalendarUiState,
    poolUiState: BaPoolUiState,
    officePageUiState: BaOfficePageUiState,
    clockState: BaPageClockState,
    serverOptions: List<String>,
    cafeLevelOptions: List<Int>,
): BaPagePresentationState {
    val routeState =
        buildBaPageRouteState(
            calendarUiState = calendarUiState,
            poolUiState = poolUiState,
            chromeUiState = officePageUiState.chromeUiState,
            syncUiState = officePageUiState.syncUiState,
            accountUiState = officePageUiState.accountUiState,
            serverUiState = officePageUiState.serverUiState,
            runtimeUiState = officePageUiState.runtimeUiState,
            settingsDraftUiState = officePageUiState.settingsDraftUiState,
            notificationDraftUiState = officePageUiState.notificationDraftUiState,
        )
    val settingsSheetState =
        buildBaSettingsSheetState(
            draft = routeState.settingsDraftState,
        )
    val notificationSettingsSheetState =
        buildBaNotificationSettingsSheetState(
            draft = routeState.notificationDraftState,
        )
    val savedSettingsDraftState =
        buildBaSavedSettingsDraftState(
            officeState = officeState,
            routeState = routeState,
        )
    val savedSettingsSheetState =
        buildBaSettingsSheetState(
            draft = savedSettingsDraftState,
        )
    val savedNotificationSettingsSheetState =
        buildBaNotificationSettingsSheetState(
            officePageUiState.notificationDraftUiState.savedDraft,
        )
    val pageContentState =
        buildBaPageContentState(
            officeState = officeState,
            routeState = routeState,
            clockState = clockState,
            serverOptions = serverOptions,
            cafeLevelOptions = cafeLevelOptions,
        )
    return BaPagePresentationState(
        routeState = routeState,
        settingsSheetState = settingsSheetState,
        notificationSettingsSheetState = notificationSettingsSheetState,
        savedSettingsDraftState = savedSettingsDraftState,
        savedSettingsSheetState = savedSettingsSheetState,
        savedNotificationSettingsSheetState = savedNotificationSettingsSheetState,
        pageContentState = pageContentState,
    )
}

internal fun buildBaSavedSettingsDraftState(
    officeState: BaOfficeState,
    routeState: BaPageRouteState,
): BaPageSettingsDraftState =
    BaPageSettingsDraftState(
        cafeLevel = officeState.cafeLevel,
        mediaAdaptiveRotationEnabled = routeState.mediaAdaptiveRotationEnabled,
        mediaSaveCustomEnabled = routeState.mediaSaveCustomEnabled,
        mediaSaveFixedTreeUri = routeState.mediaSaveFixedTreeUri,
    )
