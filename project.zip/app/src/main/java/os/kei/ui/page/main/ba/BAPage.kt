@file:Suppress("FunctionName")

package os.kei.ui.page.main.ba

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import os.kei.R
import os.kei.core.ext.showToast
import os.kei.core.ui.effect.rememberAppTopBarColor
import os.kei.ui.page.main.ba.support.BaAccountId
import os.kei.ui.page.main.ba.support.BASessionState
import os.kei.ui.page.main.common.applicationViewModel
import os.kei.ui.page.main.host.pager.MainPageBackdropSet
import os.kei.ui.page.main.host.pager.MainPageContentBackdropScene
import os.kei.ui.page.main.host.pager.MainPageRuntime
import os.kei.ui.page.main.host.pager.rememberMainPageBackdropSet
import os.kei.ui.page.main.widget.chrome.AppScaffold
import os.kei.ui.page.main.widget.chrome.LocalAppPageContentMaxWidth
import os.kei.ui.page.main.widget.chrome.appPageColumnCount
import os.kei.ui.page.main.widget.chrome.appPageContentMaxWidthFor
import os.kei.ui.page.main.widget.chrome.AppTopEndActionBarOverlay
import os.kei.ui.page.main.widget.glass.LocalGlassEffectRuntime
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior

@Composable
fun BAPage(
    runtime: MainPageRuntime = MainPageRuntime(contentBottomPadding = 72.dp),
    preloadingEnabled: Boolean = false,
    onOpenPoolStudentGuide: (String) -> Unit = {},
    onOpenGuideCatalog: () -> Unit = {},
    onOpenCalendarPool: (Int?) -> Unit = {},
    requestedAccountId: String? = null,
    requestedAccountToken: Int = 0,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val pageScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val secondaryListState = rememberLazyListState()
    // Two columns on a tablet or an unfolded fold, one everywhere else. Eighteen office cards, all
    // independent and most of them one line tall collapsed.
    val baColumnCount = appPageColumnCount()
    val wideBaLayout = baColumnCount >= 2
    val saveFailedFormat = stringResource(R.string.common_save_failed_with_reason)
    val scrollBehavior = MiuixScrollBehavior()
    val pageBackdropEffectsEnabled =
        runtime.isPageActive &&
            !runtime.isPagerScrollInProgress
    val topBarMaterialBackdrop = rememberAppTopBarColor(enableBackdropEffects = pageBackdropEffectsEnabled)
    val baServerCn = stringResource(R.string.ba_server_cn)
    val baServerGlobal = stringResource(R.string.ba_server_global)
    val baServerJp = stringResource(R.string.ba_server_jp)
    val serverOptions =
        remember(baServerCn, baServerGlobal, baServerJp) {
            listOf(
                baServerCn,
                baServerGlobal,
                baServerJp,
            )
        }
    val cafeLevelOptions = remember { (1..10).toList() }
    val officeViewModel: BaOfficeViewModel = applicationViewModel(create = ::BaOfficeViewModel)

    // Reset once per cold process start so app relaunch always lands at BA top.
    LaunchedEffect(Unit) {
        if (!BASessionState.didResetScrollOnThisProcess) {
            officeViewModel.clearListScrollState()
            listState.scrollToItem(0)
            BASessionState.didResetScrollOnThisProcess = true
        }
    }

    val officePageUiState by officeViewModel.pageUiState.collectAsStateWithLifecycle()
    val officeChromeUiState = officePageUiState.chromeUiState
    val sheetBackdropVisible = officeChromeUiState.hasVisiblePageSheet
    val backdrops =
        rememberBaPageBackdropSet(
            pageBackdropEffectsEnabled = pageBackdropEffectsEnabled,
            sheetBackdropVisible = sheetBackdropVisible,
        )
    val office = officeViewModel.office
    val officeState = office.state()
    val ui = rememberBaPageUiController()
    val calendarPoolViewModel: BaCalendarPoolViewModel = applicationViewModel(create = ::BaCalendarPoolViewModel)
    val calendarPoolRouteState by calendarPoolViewModel.routeState.collectAsStateWithLifecycle()
    val calendarPoolUnreadCounts by calendarPoolViewModel.unreadCounts.collectAsStateWithLifecycle()
    val calendarUiState = calendarPoolRouteState.calendarUiState
    val poolUiState = calendarPoolRouteState.poolUiState
    val baClockState = ui.clockState()
    val pagePresentationState =
        remember(
            officeState,
            calendarUiState,
            poolUiState,
            officePageUiState,
            baClockState,
            serverOptions,
            cafeLevelOptions,
        ) {
            buildBaPagePresentationState(
                officeState = officeState,
                calendarUiState = calendarUiState,
                poolUiState = poolUiState,
                officePageUiState = officePageUiState,
                clockState = baClockState,
                serverOptions = serverOptions,
                cafeLevelOptions = cafeLevelOptions,
            )
        }
    val baRouteState = pagePresentationState.routeState
    val accountUiState = officePageUiState.accountUiState
    val settingsSheetState = pagePresentationState.settingsSheetState
    val notificationSettingsSheetState = pagePresentationState.notificationSettingsSheetState
    val savedSettingsDraftState = pagePresentationState.savedSettingsDraftState
    val savedSettingsSheetState = pagePresentationState.savedSettingsSheetState
    val savedNotificationSettingsSheetState = pagePresentationState.savedNotificationSettingsSheetState
    val pageContentState = pagePresentationState.pageContentState
    val currentServerIndexState = rememberUpdatedState(baRouteState.serverIndex)
    val currentActiveAccountIdState = rememberUpdatedState(accountUiState.activeAccountId)
    val handledRequestedAccountTokenState = remember { mutableIntStateOf(0) }
    val uiNowMsProvider = remember(ui) { { ui.uiNowMs } }
    val settledWorkActive =
        rememberBaPageSettledWorkActive(
            active = runtime.isSettledDataActive,
        )
    val runtimeEffectsActive =
        shouldRunBaRuntimeEffects(
            isPageActive = settledWorkActive,
            activeAccountId = accountUiState.activeAccountId,
        )
    val baGlassRuntime = LocalGlassEffectRuntime.current
    val runtimePersistenceCoordinator =
        rememberBaRuntimePersistenceCoordinator(
            accountIdProvider = { currentActiveAccountIdState.value },
        )

    fun openSettingsSheet() {
        officeViewModel.showSettingsSheet(savedSettingsDraftState)
    }

    fun closeSettingsSheet() {
        officeViewModel.hideSettingsSheet(savedSettingsDraftState)
    }

    fun openAccountManagementSheet(initialEditAccountId: BaAccountId? = null) {
        officeViewModel.showAccountManagementSheet(initialEditAccountId)
    }

    fun closeAccountManagementSheet() {
        officeViewModel.hideAccountManagementSheet()
    }

    fun openNotificationSettingsSheet() {
        officeViewModel.showNotificationSettingsSheet()
    }

    fun closeNotificationSettingsSheet() {
        officeViewModel.hideNotificationSettingsSheet()
    }

    fun refreshCalendar(force: Boolean = false) {
        officeViewModel.refreshCalendar(force)
    }

    fun refreshPool(force: Boolean = false) {
        officeViewModel.refreshPool(force)
    }

    fun refreshAllBaData() {
        runtimePersistenceCoordinator.submit(office.applyRuntimeTick())
        refreshCalendar(force = true)
        refreshPool(force = true)
    }

    LaunchedEffect(
        requestedAccountToken,
        requestedAccountId,
        accountUiState.accounts,
    ) {
        if (requestedAccountToken <= handledRequestedAccountTokenState.intValue) return@LaunchedEffect
        val targetAccountId =
            requestedAccountId
                ?.trim()
                ?.takeIf { it.isNotBlank() }
                ?.let(::BaAccountId)
                ?: run {
                    handledRequestedAccountTokenState.intValue = requestedAccountToken
                    return@LaunchedEffect
                }
        if (accountUiState.activeAccountId == targetAccountId) {
            handledRequestedAccountTokenState.intValue = requestedAccountToken
            return@LaunchedEffect
        }
        if (accountUiState.accounts.none { it.id == targetAccountId }) return@LaunchedEffect
        handledRequestedAccountTokenState.intValue = requestedAccountToken
        officeViewModel.selectActiveAccount(
            accountId = targetAccountId,
            currentRuntimeUpdate =
                office
                    .applyRuntimeTick()
                    ?.withAccountId(currentActiveAccountIdState.value),
        )
    }

    LaunchedEffect(officeViewModel, context) {
        officeViewModel.events.collect { event ->
            when (event) {
                is BaOfficeEvent.SettingsSaved -> {
                    runtimePersistenceCoordinator.submit(event.clampUpdate)
                    runtimePersistenceCoordinator.submit(event.runtimeUpdate)
                    officeViewModel.hideSettingsSheet(
                        BaPageSettingsDraftState(
                            cafeLevel = event.persisted.savedCafeLevel,
                            mediaAdaptiveRotationEnabled = event.persisted.mediaAdaptiveRotationEnabled,
                            mediaSaveCustomEnabled = event.persisted.mediaSaveCustomEnabled,
                            mediaSaveFixedTreeUri = event.persisted.mediaSaveFixedTreeUri,
                        ),
                    )
                }

                is BaOfficeEvent.NotificationSettingsSaved -> {
                    runtimePersistenceCoordinator.submit(event.runtimeUpdate)
                    officeViewModel.hideNotificationSettingsSheet()
                }

                is BaOfficeEvent.OperationFailed -> {
                    context.showToast(
                        saveFailedFormat.format(event.error.message ?: event.error.javaClass.simpleName),
                    )
                }
            }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer =
            LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    officeViewModel.refreshRuntimeSettingsFromStore()
                    officeViewModel.restoreServerFromStore()
                    calendarPoolViewModel.refreshUnreadCounts(currentServerIndexState.value)
                }
            }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    fun saveSettings() {
        runtimePersistenceCoordinator.submit(office.applyRuntimeTick())
        officeViewModel.saveSettings(
            sheetState = settingsSheetState,
        )
    }

    fun saveNotificationSettings() {
        runtimePersistenceCoordinator.submit(office.applyRuntimeTick())
        officeViewModel.saveNotificationSettings(
            sheetState = notificationSettingsSheetState,
            serverIndex = baRouteState.serverIndex,
        )
    }

    val pageContentActions =
        remember(
            context,
            office,
            pageScope,
            officeViewModel,
            onOpenPoolStudentGuide,
        ) {
            buildBaPageContentActions(
                context = context,
                office = office,
                scope = pageScope,
                serverIndexProvider = { currentServerIndexState.value },
                accountIdProvider = { currentActiveAccountIdState.value },
                onSettingsCafeLevelChange = { level ->
                    officeViewModel.updateSettingsDraft { draft -> draft.copy(cafeLevel = level) }
                },
                onCafeLevelPopupChange = officeViewModel::updateCafeLevelPopupExpanded,
                onOpenApLimitTools = officeViewModel::showApLimitToolsSheet,
                onOpenCafeApTools = officeViewModel::showCafeApToolsSheet,
                onOpenCafeCooldownEditSheet = officeViewModel::showCafeCooldownEditSheet,
                onOpenCraftSlotEditSheet = officeViewModel::showCraftSlotEditSheet,
                onCraftCardExpandedChange = officeViewModel::updateCraftCardExpanded,
                onAccountSelected = { accountId ->
                    officeViewModel.selectActiveAccount(
                        accountId = accountId,
                        currentRuntimeUpdate =
                            office
                                .applyRuntimeTick()
                                ?.withAccountId(currentActiveAccountIdState.value),
                    )
                },
                onEditAccount = { accountId -> openAccountManagementSheet(accountId) },
                onRefreshCalendar = { refreshCalendar(force = true) },
                onRefreshPool = { refreshPool(force = true) },
                onOpenCalendarLink = { url -> openBaExternalLink(context = context, url = url) },
                onOpenPoolStudentGuide = onOpenPoolStudentGuide,
            )
        }

    BaPageCommonEffects(
        listState = listState,
        secondaryListState = secondaryListState,
        wideLayout = wideBaLayout,
        scrollBehavior = scrollBehavior,
        scrollToTopSignal = runtime.scrollToTopSignal,
        isPageActive = settledWorkActive,
        consumedScrollToTopSignal = baRouteState.consumedScrollToTopSignal,
        onConsumedScrollToTopSignalChange = officeViewModel::updateConsumedScrollToTopSignal,
        office = office,
        runtimePersistenceCoordinator = runtimePersistenceCoordinator,
        onUiNowMsChange = { ui.uiNowMs = it },
        onUiMinuteMsChange = { ui.uiMinuteMs = it },
        onScrollBoundsChange = runtime.onScrollBoundsChange,
        serverIndex = baRouteState.serverIndex,
        onServerChanged = {
            officeViewModel.markCalendarPoolHydrationReady()
        },
        context = context,
        accountUiState = accountUiState,
        runtimeEffectsActive = runtimeEffectsActive,
    )

    BaCalendarPoolSyncEffects(
        calendarPoolViewModel = calendarPoolViewModel,
        syncPageActive = settledWorkActive,
        routeState = baRouteState,
    )
    LaunchedEffect(baRouteState.serverIndex, calendarPoolViewModel) {
        calendarPoolViewModel.refreshUnreadCounts(baRouteState.serverIndex)
    }
    // Published to the whole page, chrome included: BA builds its own scaffold rather than going through
    // AppPageScaffold, so it provides the cap itself. See LocalAppPageContentMaxWidth.
    CompositionLocalProvider(
        LocalGlassEffectRuntime provides baGlassRuntime,
        LocalAppPageContentMaxWidth provides appPageContentMaxWidthFor(baColumnCount),
    ) {
        MainPageContentBackdropScene(
            contentProducer = null,
            sheetProducer = backdrops.sheetProducer,
            producerActive = pageBackdropEffectsEnabled && sheetBackdropVisible,
            modifier = Modifier.fillMaxSize(),
        ) {
            AppScaffold(
                modifier = Modifier.fillMaxSize(),
                topBar = {
                    BaTopBar(
                        topBarColor = topBarMaterialBackdrop,
                        scrollBehavior = scrollBehavior,
                        titleBackdrop = backdrops.topBar,
                        onTitleClick = {
                            pageScope.launch {
                                // Both columns: the title belongs to the page, not to a lane.
                                listState.animateScrollToItem(0)
                                if (wideBaLayout) secondaryListState.animateScrollToItem(0)
                            }
                        },
                    )
                },
            ) { innerPadding ->
                BaPageContent(
                    topBarBackdrop = backdrops.topBarProducer,
                    backdrop = backdrops.contentMaterial,
                    innerPadding = innerPadding,
                    contentBottomPadding = runtime.contentBottomPadding,
                    listState = listState,
                    secondaryListState = secondaryListState,
                    columnCount = baColumnCount,
                    nestedScrollConnection = scrollBehavior.nestedScrollConnection,
                    state = pageContentState,
                    actions = pageContentActions,
                )
            }
            AppTopEndActionBarOverlay {
                BaTopBarActions(
                    backdrop = backdrops.topBar,
                    onShowAccountManagement = { openAccountManagementSheet() },
                    onShowSettings = ::openSettingsSheet,
                    onShowNotificationSettings = ::openNotificationSettingsSheet,
                )
            }
            BaPageFloatingDock(
                backdrop = backdrops.topBar,
                runtime = runtime,
                unreadCounts = calendarPoolUnreadCounts,
                onOpenCalendarPool = {
                    // The page marks each half read as its tab comes up, so nothing is cleared here: a
                    // teacher who opens the calendar has not seen the banners yet.
                    onOpenCalendarPool(currentServerIndexState.value)
                },
                onOpenGuideCatalog = onOpenGuideCatalog,
                onOpenDailyDone = officeViewModel::showDailyDoneSheet,
            )
        }

        BaPageSheetHost(
            backdrop = backdrops.sheet,
            context = context,
            office = office,
            viewModel = officeViewModel,
            runtimePersistenceCoordinator = runtimePersistenceCoordinator,
            uiNowMsProvider = uiNowMsProvider,
            routeState = baRouteState,
            chromeUiState = officeChromeUiState,
            settingsSheetState = settingsSheetState,
            notificationSettingsSheetState = notificationSettingsSheetState,
            savedSettingsSheetState = savedSettingsSheetState,
            savedNotificationSettingsSheetState = savedNotificationSettingsSheetState,
            calendarUiState = calendarUiState,
            poolUiState = poolUiState,
            accountUiState = accountUiState,
            onDismissSettings = ::closeSettingsSheet,
            onSaveSettings = ::saveSettings,
            onDismissAccountManagement = ::closeAccountManagementSheet,
            onSelectAccount = { accountId ->
                officeViewModel.selectActiveAccount(
                    accountId = accountId,
                    currentRuntimeUpdate =
                        office
                            .applyRuntimeTick()
                            ?.withAccountId(accountUiState.activeAccountId),
                )
            },
            onDismissNotificationSettings = ::closeNotificationSettingsSheet,
            onSaveNotificationSettings = ::saveNotificationSettings,
        )
    }
}

@Composable
internal fun rememberBaPageBackdropSet(
    pageBackdropEffectsEnabled: Boolean,
    sheetBackdropVisible: Boolean,
): MainPageBackdropSet =
    rememberMainPageBackdropSet(
        keyPrefix = "ba",
        refreshOnCompositionEnter = true,
        distinctLayers = pageBackdropEffectsEnabled && sheetBackdropVisible,
        useSolidSurfaceBackdrops = true,
    )
