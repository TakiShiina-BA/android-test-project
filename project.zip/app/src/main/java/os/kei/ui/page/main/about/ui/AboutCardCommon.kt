@file:Suppress("FunctionName")

package os.kei.ui.page.main.about.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow.Companion.Clip
import androidx.compose.ui.unit.dp
import os.kei.ui.page.main.widget.core.AppFeatureCard
import os.kei.ui.page.main.widget.core.AppInfoRow
import os.kei.ui.page.main.widget.core.AppTypographyTokens
import os.kei.ui.page.main.widget.core.CardLayoutRhythm
import os.kei.ui.page.main.widget.status.StatusPill
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun AboutCompactRow(
    title: String,
    modifier: Modifier = Modifier,
    titleIcon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    valueContent: @Composable RowScope.() -> Unit,
) {
    val clickableModifier =
        if (onClick != null || onLongClick != null) {
            val interactionSource = remember { MutableInteractionSource() }
            if (onLongClick != null) {
                Modifier.combinedClickable(
                    interactionSource = interactionSource,
                    indication = null,
                    role = Role.Button,
                    onClick = { onClick?.invoke() },
                    onLongClick = onLongClick,
                )
            } else {
                Modifier.clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    role = Role.Button,
                    onClick = { onClick?.invoke() },
                )
            }
        } else {
            Modifier
        }
    BoxWithConstraints(
        modifier =
            modifier
                .fillMaxWidth()
                .then(clickableModifier)
                .padding(vertical = CardLayoutRhythm.compactSectionGap),
    ) {
        val maxTitleWidth = (maxWidth * 0.44f).coerceAtLeast(96.dp)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(CardLayoutRhythm.infoRowGap),
        ) {
            Row(
                modifier = Modifier.widthIn(min = 70.dp, max = maxTitleWidth),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (titleIcon != null) {
                    Icon(
                        imageVector = titleIcon,
                        contentDescription = null,
                        tint = MiuixTheme.colorScheme.onBackgroundVariant,
                    )
                }
                Text(
                    text = title,
                    color = MiuixTheme.colorScheme.onBackgroundVariant.copy(alpha = 0.86f),
                    fontSize = AppTypographyTokens.Supporting.fontSize,
                    lineHeight = AppTypographyTokens.Supporting.lineHeight,
                    maxLines = Int.MAX_VALUE,
                    overflow = Clip,
                )
            }
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
                content = valueContent,
            )
        }
    }
}

@Composable
fun AboutCompactInfoRow(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    titleIcon: ImageVector? = null,
    valueColor: Color = MiuixTheme.colorScheme.onBackground,
    onClick: (() -> Unit)? = null,
    enableLongPressCopy: Boolean = true,
    onLongClick: (() -> Unit)? = null,
) {
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val maxTitleWidth = (maxWidth * 0.44f).coerceAtLeast(96.dp)
        AppInfoRow(
            label = title,
            value = value,
            labelColor = MiuixTheme.colorScheme.onBackgroundVariant.copy(alpha = 0.86f),
            valueColor = valueColor,
            labelMinWidth = 70.dp,
            labelMaxWidth = maxTitleWidth,
            horizontalSpacing = CardLayoutRhythm.infoRowGap,
            rowVerticalPadding = CardLayoutRhythm.compactSectionGap,
            emphasizedValue = false,
            onClick = onClick,
            onLongClick = onLongClick,
            labelLeadingContent =
                if (titleIcon == null) {
                    null
                } else {
                    {
                        Icon(
                            imageVector = titleIcon,
                            contentDescription = null,
                            tint = MiuixTheme.colorScheme.onBackgroundVariant,
                        )
                    }
                },
            labelContentSpacing = 6.dp,
            enableLongPressCopy = enableLongPressCopy,
        )
    }
}

@Composable
fun AboutCompactPillRow(
    title: String,
    label: String,
    color: Color,
    titleIcon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
) {
    AboutCompactRow(
        title = title,
        titleIcon = titleIcon,
        onClick = onClick,
    ) {
        StatusPill(
            label = label,
            color = color,
        )
    }
}

@Composable
fun AboutSectionCard(
    cardColor: Color,
    title: String,
    subtitle: String,
    titleColor: Color,
    subtitleColor: Color,
    sectionIcon: ImageVector? = null,
    collapsible: Boolean = false,
    expanded: Boolean = true,
    onExpandedChange: (Boolean) -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    AppFeatureCard(
        title = title,
        subtitle = subtitle,
        containerColor = cardColor,
        titleColor = titleColor,
        subtitleColor = subtitleColor,
        sectionIcon = sectionIcon,
        collapsible = collapsible,
        expanded = expanded,
        onExpandedChange = onExpandedChange,
        content = content,
    )
}
