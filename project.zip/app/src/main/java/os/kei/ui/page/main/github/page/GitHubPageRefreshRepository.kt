package os.kei.ui.page.main.github.page

import android.content.Context
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import os.kei.core.concurrency.AppDispatchers
import os.kei.feature.github.data.remote.GitHubReleaseStrategyRegistry
import os.kei.feature.github.domain.GitHubReleaseCheckService
import os.kei.feature.github.domain.GitHubRefreshScope
import os.kei.feature.github.domain.GitHubRefreshSource
import os.kei.feature.github.domain.GitHubTrackedRefreshBatchEvaluator
import os.kei.feature.github.model.GitHubRepositoryProfilePurpose
import os.kei.feature.github.model.GitHubRepositoryProfileSnapshot
import os.kei.feature.github.model.GitHubTrackedApp
import os.kei.ui.page.main.github.VersionCheckUi
import os.kei.ui.page.main.github.state.toUi

internal class GitHubPageRefreshRepository(
    private val ioDispatcher: CoroutineDispatcher = AppDispatchers.githubNetwork
) {
    private val notificationBridge = GitHubPageRefreshNotificationBridge()

    suspend fun evaluateTrackedApp(
        context: Context,
        item: GitHubTrackedApp,
        profilePurposeOverride: GitHubRepositoryProfilePurpose? = null,
        forceRefresh: Boolean = false,
        existingRepositoryProfile: GitHubRepositoryProfileSnapshot? = null,
        batchEvaluator: GitHubTrackedRefreshBatchEvaluator? = null
    ): VersionCheckUi {
        return withContext(ioDispatcher) {
            val check =
                batchEvaluator?.evaluateTrackedApp(
                    context = context,
                    item = item,
                    profilePurposeOverride = profilePurposeOverride,
                    forceRefresh = forceRefresh
                ) ?: GitHubReleaseCheckService.evaluateTrackedApp(
                    context = context,
                    item = item,
                    profilePurposeOverride = profilePurposeOverride,
                    forceRefresh = forceRefresh,
                    existingRepositoryProfile = existingRepositoryProfile
                )
            check.toUi()
        }
    }

    suspend fun notifyRefreshProgress(
        context: Context,
        current: Int,
        total: Int,
        preReleaseUpdateCount: Int,
        updatableCount: Int,
        failedCount: Int,
        sessionId: Long,
        scope: GitHubRefreshScope,
        source: GitHubRefreshSource,
        totalTrackedCount: Int
    ): Boolean {
        return notificationBridge.notifyProgress(
            context = context,
            current = current,
            total = total,
            preReleaseUpdateCount = preReleaseUpdateCount,
            updatableCount = updatableCount,
            failedCount = failedCount,
            sessionId = sessionId,
            scope = scope,
            source = source,
            totalTrackedCount = totalTrackedCount
        )
    }

    suspend fun notifyRefreshCompleted(
        context: Context,
        total: Int,
        preReleaseUpdateCount: Int,
        updatableCount: Int,
        failedCount: Int,
        sessionId: Long,
        scope: GitHubRefreshScope,
        source: GitHubRefreshSource,
        totalTrackedCount: Int
    ): Boolean {
        return notificationBridge.notifyCompleted(
            context = context,
            total = total,
            preReleaseUpdateCount = preReleaseUpdateCount,
            updatableCount = updatableCount,
            failedCount = failedCount,
            sessionId = sessionId,
            scope = scope,
            source = source,
            totalTrackedCount = totalTrackedCount
        )
    }

    suspend fun notifyRefreshFailed(
        context: Context,
        current: Int,
        total: Int,
        preReleaseUpdateCount: Int,
        updatableCount: Int,
        failedCount: Int,
        sessionId: Long,
        scope: GitHubRefreshScope,
        source: GitHubRefreshSource,
        totalTrackedCount: Int
    ): Boolean {
        return notificationBridge.notifyFailed(
            context = context,
            current = current,
            total = total,
            preReleaseUpdateCount = preReleaseUpdateCount,
            updatableCount = updatableCount,
            failedCount = failedCount,
            sessionId = sessionId,
            scope = scope,
            source = source,
            totalTrackedCount = totalTrackedCount
        )
    }

    suspend fun notifyRefreshCancelled(
        context: Context,
        current: Int,
        total: Int,
        preReleaseUpdateCount: Int,
        updatableCount: Int,
        failedCount: Int,
        sessionId: Long,
        scope: GitHubRefreshScope,
        source: GitHubRefreshSource,
        totalTrackedCount: Int
    ): Boolean {
        return notificationBridge.notifyCancelled(
            context = context,
            current = current,
            total = total,
            preReleaseUpdateCount = preReleaseUpdateCount,
            updatableCount = updatableCount,
            failedCount = failedCount,
            sessionId = sessionId,
            scope = scope,
            source = source,
            totalTrackedCount = totalTrackedCount
        )
    }

    fun cancelRefreshNotification(
        context: Context,
        sessionId: Long,
    ) {
        notificationBridge.cancel(context, sessionId)
    }

    suspend fun clearReleaseStrategyCaches() {
        withContext(ioDispatcher) {
            GitHubReleaseStrategyRegistry.clearAllCaches()
        }
    }
}
