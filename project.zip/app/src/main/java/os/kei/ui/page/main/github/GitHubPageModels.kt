package os.kei.ui.page.main.github

import android.content.Context
import androidx.annotation.StringRes
import androidx.compose.runtime.Immutable
import os.kei.R
import os.kei.feature.github.data.remote.GitHubVersionUtils
import os.kei.feature.github.model.GitHubActionsLookupStrategyOption
import os.kei.feature.github.model.GitHubDirectApkRemoteHealth
import os.kei.feature.github.model.GitHubLookupConfig
import os.kei.feature.github.model.GitHubLookupStrategyOption
import os.kei.feature.github.model.GitHubReleaseDecisionNote
import os.kei.feature.github.model.GitHubRemoteApkVersionInfo
import os.kei.feature.github.model.GitHubRepositoryProfileSnapshot
import os.kei.feature.github.model.GitHubTrackedApp
import kotlin.math.max

@Immutable
internal data class VersionCheckUi(
    val loading: Boolean = false,
    val localVersion: String = "",
    val localVersionCode: Long = -1L,
    val latestTag: String = "",
    val latestStableName: String = "",
    val latestStableRawTag: String = "",
    val latestStableUrl: String = "",
    val latestStableAuthorAvatarUrl: String = "",
    val latestStableUpdatedAtMillis: Long = -1L,
    val latestPreName: String = "",
    val latestPreRawTag: String = "",
    val latestPreUrl: String = "",
    val latestPreAuthorAvatarUrl: String = "",
    val latestPreUpdatedAtMillis: Long = -1L,
    val hasStableRelease: Boolean = true,
    val hasUpdate: Boolean? = null,
    val message: String = "",
    val isPreRelease: Boolean = false,
    val preReleaseInfo: String = "",
    val showPreReleaseInfo: Boolean = false,
    val hasPreReleaseUpdate: Boolean = false,
    val recommendsPreRelease: Boolean = false,
    val releaseHint: String = "",
    val failed: Boolean = false,
    val sourceStrategyId: String = "",
    val sourceConfigSignature: String = "",
    val latestStableApkVersion: GitHubRemoteApkVersionInfo? = null,
    val latestPreApkVersion: GitHubRemoteApkVersionInfo? = null,
    val repositoryArchived: Boolean = false,
    val repositoryFork: Boolean = false,
    val repositoryPushedAtMillis: Long = -1L,
    val upstreamFullName: String = "",
    val upstreamArchived: Boolean = false,
    val upstreamPushedAtMillis: Long = -1L,
    val repositoryProfile: GitHubRepositoryProfileSnapshot? = null,
    val directApkRemoteHealth: GitHubDirectApkRemoteHealth = GitHubDirectApkRemoteHealth.Unknown,
    val directApkRemoteHealthMessage: String = "",
    val directApkRemoteCheckedAtMillis: Long = -1L,
    val checkedAtMillis: Long = -1L,
    /** Why this check chose the release it shows, for the cases where that is worth saying. */
    val decisionNote: GitHubReleaseDecisionNote = GitHubReleaseDecisionNote()
)

internal fun GitHubTrackedApp.isRepositoryArchived(state: VersionCheckUi?): Boolean {
    return state
        ?.takeIf { it.checkedAtMillis > 0L }
        ?.repositoryArchived
        ?: repositoryArchived
}

@Immutable
internal data class GitHubStrategyGuide(
    val option: GitHubLookupStrategyOption,
    val summary: String,
    val pros: List<String>,
    val cons: List<String>,
    val requirement: String
)

@Immutable
internal data class GitHubActionsStrategyGuide(
    val option: GitHubActionsLookupStrategyOption,
    val summary: String,
    val pros: List<String>,
    val cons: List<String>,
    val requirement: String
)

internal data class GitHubTokenGuideField(
    val label: String,
    val value: String,
    val emphasized: Boolean = false
)

@Immutable
internal data class GitHubRecommendedTokenGuide(
    val collapsedSummary: String,
    val summary: String,
    val fields: List<GitHubTokenGuideField>,
    val notes: List<String>
)

internal enum class GitHubSortMode(
    val storageId: String,
    @get:StringRes val labelRes: Int
) {
    Update("update", R.string.github_sort_rule_update),
    Name("name", R.string.github_sort_rule_name),
    PreRelease("pre_release", R.string.github_sort_rule_prerelease),
    Changed("changed", R.string.github_sort_rule_changed),
    Added("added", R.string.github_sort_rule_added);

    companion object {
        fun fromStorageId(value: String): GitHubSortMode? {
            return entries.firstOrNull { it.storageId == value }
        }
    }
}

internal enum class GitHubSortDirection(
    val storageId: String,
    @get:StringRes val labelRes: Int
) {
    Forward("forward", R.string.github_sort_direction_forward),
    Reverse("reverse", R.string.github_sort_direction_reverse);

    companion object {
        fun fromStorageId(value: String): GitHubSortDirection? {
            return entries.firstOrNull { it.storageId == value }
        }
    }
}

internal enum class GitHubTrackedFilterMode(
    val storageId: String,
    @get:StringRes val labelRes: Int
) {
    All("all", R.string.github_filter_all),
    GitHubRepository("github_repository", R.string.github_filter_github_repository),
    GitRepository("git_repository", R.string.github_filter_git_repository),
    DirectApk("direct_apk", R.string.github_filter_direct_apk),
    FdroidRepository("fdroid_repository", R.string.github_filter_fdroid_repository),
    PreReleaseTracked("pre_release_tracked", R.string.github_filter_prerelease_tracked),
    UpdateAvailable("update_available", R.string.github_filter_update_available),
    Installed("installed", R.string.github_filter_installed),
    FailedChecks("failed_checks", R.string.github_filter_failed_checks),
    ActionsCheckEnabled("actions_check_enabled", R.string.github_filter_actions_check_enabled);

    companion object {
        fun fromStorageId(value: String): GitHubTrackedFilterMode? {
            return entries.firstOrNull { it.storageId == value }
        }
    }
}

internal enum class OverviewRefreshState {
    Idle,
    Cached,
    Refreshing,
    Completed,
    Failed
}

internal enum class RefreshIntervalOption(
    val hours: Int,
    @get:StringRes val labelRes: Int
) {
    Hour1(1, R.string.github_refresh_interval_1h),
    Hour3(3, R.string.github_refresh_interval_3h),
    Hour6(6, R.string.github_refresh_interval_6h),
    Hour12(12, R.string.github_refresh_interval_12h);

    companion object {
        fun fromHours(hours: Int): RefreshIntervalOption {
            return entries.firstOrNull { it.hours == hours } ?: Hour3
        }
    }
}

internal fun formatRefreshAgo(
    context: Context,
    lastRefreshMs: Long,
    nowMs: Long = System.currentTimeMillis()
): String {
    if (lastRefreshMs <= 0L) return context.getString(R.string.github_refresh_ago_not_refreshed)
    val deltaMs = max(0L, nowMs - lastRefreshMs)
    val minutes = deltaMs / 60_000L
    if (minutes <= 0L) return context.getString(R.string.common_just_now)
    if (minutes < 60L) return "${minutes}m"
    val hours = minutes / 60L
    val mins = minutes % 60L
    val days = hours / 24L
    val remainHours = hours % 24L
    return when {
        days > 0L && mins == 0L -> "${days}d ${remainHours}h"
        days > 0L -> "${days}d ${remainHours}h ${mins}m"
        mins == 0L -> "${hours}h"
        else -> "${hours}h ${mins}m"
    }
}

internal fun formatFutureEta(
    context: Context,
    targetMs: Long?,
    nowMs: Long = System.currentTimeMillis()
): String {
    if (targetMs == null || targetMs <= 0L) return context.getString(R.string.common_unknown)
    val deltaMs = (targetMs - nowMs).coerceAtLeast(0L)
    val minutes = deltaMs / 60_000L
    if (minutes <= 0L) return context.getString(R.string.github_eta_soon_recover)
    if (minutes < 60L) return context.getString(R.string.github_eta_after_minutes, minutes)
    val hours = minutes / 60L
    val mins = minutes % 60L
    return if (mins == 0L) {
        context.getString(R.string.github_eta_after_hours, hours)
    } else {
        context.getString(R.string.github_eta_after_hours_minutes, hours, mins)
    }
}

internal fun strategyLabelForId(id: String): String {
    return GitHubLookupStrategyOption.fromStorageId(id).label
}

internal fun GitHubLookupStrategyOption.overviewLabel(context: Context): String {
    return when (this) {
        GitHubLookupStrategyOption.AtomFeed -> context.getString(R.string.github_overview_strategy_atom)
        GitHubLookupStrategyOption.GitHubApiToken -> context.getString(R.string.github_overview_strategy_api)
    }
}

internal fun GitHubLookupConfig.overviewLookupPillLabel(context: Context): String {
    return selectedStrategy.overviewLabel(context)
}

internal fun GitHubActionsLookupStrategyOption.overviewLabel(context: Context): String {
    return when (this) {
        GitHubActionsLookupStrategyOption.NightlyLink ->
            context.getString(R.string.github_overview_actions_strategy_nightly)
        GitHubActionsLookupStrategyOption.GitHubApiToken ->
            context.getString(R.string.github_overview_strategy_api)
    }
}

private fun String.normalizeVersionPrefix(): String {
    return trim().removePrefix("v").removePrefix("V")
}

private fun String.removeIgnoreCase(token: String): String {
    if (token.isBlank()) return this
    return replace(token, " ", ignoreCase = true)
}

private fun String.compactVersionCandidate(): String? {
    return GitHubVersionUtils.normalizeVersionCandidates(this)
        .map { it.normalizeVersionPrefix() }
        .filter { it.isNotBlank() }
        .minWithOrNull(
            compareBy<String>(
                { candidate -> candidate.count(Char::isLetter) },
                { candidate -> candidate.length },
                { candidate -> candidate }
            )
        )
}

private fun preferredTagDisplayValue(
    releaseName: String,
    rawTag: String
): String? {
    val name = releaseName.trim()
    val tag = rawTag.trim()
    if (name.isBlank() || tag.isBlank()) return null

    val tagVersion = tag.compactVersionCandidate() ?: return null
    val nameCarriesSameVersion = GitHubVersionUtils.compareCandidateSets(
        leftCandidates = listOf(tagVersion),
        rightCandidates = GitHubVersionUtils.normalizeVersionCandidates(name)
    ) == 0
    if (!nameCarriesSameVersion) return null

    val normalizedName = name.normalizeVersionPrefix()
    val normalizedTag = tag.normalizeVersionPrefix()
    if (normalizedName.equals(normalizedTag, ignoreCase = true)) return null

    val residualLetters = name
        .removeIgnoreCase(tag)
        .removeIgnoreCase(normalizedTag)
        .removeIgnoreCase(tagVersion)
        .filter(Char::isLetter)
    return tagVersion.takeIf { residualLetters.isNotBlank() }
}

internal fun formatReleaseValue(
    releaseName: String,
    rawTag: String
): String {
    val name = releaseName.trim()
    val tag = rawTag.trim()
    preferredTagDisplayValue(name, tag)?.let { return it }
    val normalizedName = name.normalizeVersionPrefix()
    val normalizedTag = tag.normalizeVersionPrefix()
    return when {
        name.isBlank() -> normalizedTag.ifBlank { tag }
        tag.isBlank() -> normalizedName.ifBlank { name }
        name.equals(tag, ignoreCase = true) -> name
        normalizedName.equals(normalizedTag, ignoreCase = true) -> normalizedName.ifBlank { normalizedTag }
        else -> "$name · $tag"
    }
}

internal fun formatApkVersionValue(
    preciseInfo: GitHubRemoteApkVersionInfo?,
    releaseName: String,
    rawTag: String
): String {
    return preciseInfo?.versionLabel()?.takeIf { it.isNotBlank() }
        ?: formatReleaseValue(releaseName = releaseName, rawTag = rawTag)
}

internal fun formatReleaseMetaValue(
    preciseInfo: GitHubRemoteApkVersionInfo?,
    releaseName: String,
    rawTag: String
): String {
    preciseInfo?.releaseLabel()?.takeIf { it.isNotBlank() }?.let { return it }
    val name = releaseName.trim()
    val tag = rawTag.trim()
    return when {
        name.isBlank() -> tag
        tag.isBlank() -> name
        name.equals(tag, ignoreCase = true) -> name
        else -> "$name · $tag"
    }
}

internal fun VersionCheckUi.statusActionUrl(
    owner: String,
    repo: String
): String {
    return when {
        recommendsPreRelease && latestPreUrl.isNotBlank() -> latestPreUrl
        recommendsPreRelease && latestPreRawTag.isNotBlank() ->
            GitHubVersionUtils.buildReleaseTagUrl(owner, repo, latestPreRawTag)
        hasUpdate == true && latestStableUrl.isNotBlank() -> latestStableUrl
        hasUpdate == true && latestStableRawTag.isNotBlank() ->
            GitHubVersionUtils.buildReleaseTagUrl(owner, repo, latestStableRawTag)
        hasPreReleaseUpdate && latestPreUrl.isNotBlank() -> latestPreUrl
        hasPreReleaseUpdate && latestPreRawTag.isNotBlank() ->
            GitHubVersionUtils.buildReleaseTagUrl(owner, repo, latestPreRawTag)
        else -> ""
    }
}

internal const val githubFineGrainedPatDocsUrl =
    "https://docs.github.com/en/enterprise-cloud@latest/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens?apiVersion=2022-11-28"

internal fun buildGitHubFineGrainedTokenTemplateUrl(): String {
    return "https://github.com/settings/personal-access-tokens/new" +
        "?name=KeiOS%20Release%20Read" +
        "&description=Read-only%20GitHub%20release%20and%20actions%20token%20for%20KeiOS" +
        "&expires_in=90" +
        "&contents=read" +
        "&actions=read"
}

internal fun githubRecommendedTokenGuide(context: Context): GitHubRecommendedTokenGuide {
    return GitHubRecommendedTokenGuide(
        collapsedSummary = context.getString(R.string.github_token_guide_collapsed),
        summary = context.getString(R.string.github_token_guide_summary),
        fields = listOf(
            GitHubTokenGuideField(
                label = context.getString(R.string.github_token_guide_field_type),
                value = context.getString(R.string.github_token_guide_field_type_value),
                emphasized = true
            ),
            GitHubTokenGuideField(
                label = context.getString(R.string.github_token_guide_field_owner),
                value = context.getString(R.string.github_token_guide_field_owner_value)
            ),
            GitHubTokenGuideField(
                label = context.getString(R.string.github_token_guide_field_repo),
                value = context.getString(R.string.github_token_guide_field_repo_value)
            ),
            GitHubTokenGuideField(
                label = context.getString(R.string.github_token_guide_field_limit),
                value = context.getString(R.string.github_token_guide_field_limit_value)
            ),
            GitHubTokenGuideField(
                label = context.getString(R.string.github_token_guide_field_permission),
                value = context.getString(R.string.github_token_guide_field_permission_value),
                emphasized = true
            ),
            GitHubTokenGuideField(
                label = context.getString(R.string.github_token_guide_field_expire),
                value = context.getString(R.string.github_token_guide_field_expire_value)
            )
        ),
        notes = listOf(
            context.getString(R.string.github_token_guide_note_1),
            context.getString(R.string.github_token_guide_note_2),
            context.getString(R.string.github_token_guide_note_3),
            context.getString(R.string.github_token_guide_note_4)
        )
    )
}

internal fun githubStrategyGuides(context: Context): List<GitHubStrategyGuide> = listOf(
    GitHubStrategyGuide(
        option = GitHubLookupStrategyOption.AtomFeed,
        summary = context.getString(R.string.github_strategy_guide_atom_summary),
        pros = listOf(
            context.getString(R.string.github_strategy_guide_atom_pro_1),
            context.getString(R.string.github_strategy_guide_atom_pro_2)
        ),
        cons = listOf(
            context.getString(R.string.github_strategy_guide_atom_con_1),
            context.getString(R.string.github_strategy_guide_atom_con_2)
        ),
        requirement = context.getString(R.string.github_strategy_guide_atom_requirement)
    ),
    GitHubStrategyGuide(
        option = GitHubLookupStrategyOption.GitHubApiToken,
        summary = context.getString(R.string.github_strategy_guide_api_summary),
        pros = listOf(
            context.getString(R.string.github_strategy_guide_api_pro_1),
            context.getString(R.string.github_strategy_guide_api_pro_2)
        ),
        cons = listOf(
            context.getString(R.string.github_strategy_guide_api_con_1),
            context.getString(R.string.github_strategy_guide_api_con_2)
        ),
        requirement = context.getString(R.string.github_strategy_guide_api_requirement)
    )
)

internal fun githubActionsStrategyGuides(context: Context): List<GitHubActionsStrategyGuide> = listOf(
    GitHubActionsStrategyGuide(
        option = GitHubActionsLookupStrategyOption.NightlyLink,
        summary = context.getString(R.string.github_strategy_actions_guide_nightly_summary),
        pros = listOf(
            context.getString(R.string.github_strategy_actions_guide_nightly_pro_1),
            context.getString(R.string.github_strategy_actions_guide_nightly_pro_2)
        ),
        cons = listOf(
            context.getString(R.string.github_strategy_actions_guide_nightly_con_1),
            context.getString(R.string.github_strategy_actions_guide_nightly_con_2)
        ),
        requirement = context.getString(R.string.github_strategy_actions_guide_nightly_requirement)
    ),
    GitHubActionsStrategyGuide(
        option = GitHubActionsLookupStrategyOption.GitHubApiToken,
        summary = context.getString(R.string.github_strategy_actions_guide_api_summary),
        pros = listOf(
            context.getString(R.string.github_strategy_actions_guide_api_pro_1),
            context.getString(R.string.github_strategy_actions_guide_api_pro_2)
        ),
        cons = listOf(
            context.getString(R.string.github_strategy_actions_guide_api_con_1),
            context.getString(R.string.github_strategy_actions_guide_api_con_2)
        ),
        requirement = context.getString(R.string.github_strategy_actions_guide_api_requirement)
    )
)
