package os.kei.ui.page.main.feedback

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.LocalOverscrollFactory
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import os.kei.R
import os.kei.ui.page.main.widget.sheet.SceneBackdropHost
import os.kei.core.ext.showToast
import os.kei.core.intent.SafeExternalIntents
import os.kei.core.platform.PredictiveBackOemCompat
import os.kei.core.prefs.AppThemeMode
import os.kei.core.prefs.UiPrefs
import os.kei.ui.page.main.back.ProvideBackNavigationRuntime
import os.kei.ui.page.main.common.applicationViewModel
import os.kei.ui.page.main.widget.chrome.AppManagedBackgroundHost
import os.kei.ui.page.main.widget.chrome.AppManagedBackgroundStyles
import os.kei.ui.page.main.widget.motion.LocalPredictiveBackAnimationsEnabled
import os.kei.ui.page.main.widget.motion.LocalTransitionAnimationsEnabled
import os.kei.ui.theme.AronaTheme
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.utils.MiuixOverscrollFactory

class FeedbackIssueActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialPrefsSnapshot = UiPrefs.loadSnapshot()
        val initialThemeMode = initialPrefsSnapshot.appThemeMode
        val initialTransitionAnimationsEnabled = initialPrefsSnapshot.transitionAnimationsEnabled
        val initialPredictiveBackPolicy =
            PredictiveBackOemCompat.currentPolicy(
                transitionAnimationsEnabled = initialTransitionAnimationsEnabled,
                predictiveBackAnimationsEnabled = initialPrefsSnapshot.predictiveBackAnimationsEnabled,
            )
        val initialColorSchemeMode =
            when (initialThemeMode) {
                AppThemeMode.FOLLOW_SYSTEM -> ColorSchemeMode.System
                AppThemeMode.LIGHT -> ColorSchemeMode.Light
                AppThemeMode.DARK -> ColorSchemeMode.Dark
            }

        setContent {
            AronaTheme(colorSchemeMode = initialColorSchemeMode) {
                ProvideBackNavigationRuntime(policy = initialPredictiveBackPolicy) {
                    CompositionLocalProvider(
                        LocalOverscrollFactory provides MiuixOverscrollFactory,
                        LocalTransitionAnimationsEnabled provides initialTransitionAnimationsEnabled,
                        LocalPredictiveBackAnimationsEnabled provides initialPredictiveBackPolicy.localPredictiveBackEnabled,
                    ) {
                        val viewModel: FeedbackIssueViewModel = applicationViewModel(create = ::FeedbackIssueViewModel)
                        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                        val lifecycleOwner = LocalLifecycleOwner.current
                        val exportLauncher =
                            rememberLauncherForActivityResult(
                                contract = ActivityResultContracts.CreateDocument("application/zip"),
                            ) { uri ->
                                if (uri != null) {
                                    viewModel.exportZip(uri)
                                }
                            }

                        LaunchedEffect(viewModel, lifecycleOwner, exportLauncher) {
                            lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                                viewModel.events.collect { event ->
                                    when (event) {
                                        is FeedbackIssueEvent.LaunchLogExport -> {
                                            exportLauncher.launch(event.fileName)
                                        }

                                        is FeedbackIssueEvent.OpenUrl -> {
                                            val opened =
                                                SafeExternalIntents.startBrowsableUrl(
                                                    context = this@FeedbackIssueActivity,
                                                    url = event.url,
                                                )
                                            if (!opened) {
                                                showToast(getString(R.string.common_open_link_failed))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Sheets, alerts and action sheets only get real glass where a scene backdrop exists to
                        // sample. Without this they still work, but fall back to an opaque fill.
                        SceneBackdropHost {
                            AppManagedBackgroundHost(
                                enabled = initialPrefsSnapshot.nonHomeBackgroundEnabled,
                                imageUri = initialPrefsSnapshot.nonHomeBackgroundUri,
                                opacity = initialPrefsSnapshot.nonHomeBackgroundOpacity,
                                contentScale = initialPrefsSnapshot.nonHomeBackgroundContentScale,
                                alignment = initialPrefsSnapshot.nonHomeBackgroundAlignment,
                                pageStyle = initialPrefsSnapshot.nonHomeBackgroundPageStyle,
                                scrim = initialPrefsSnapshot.nonHomeBackgroundScrim,
                                style = AppManagedBackgroundStyles.FocusedTask,
                                exportBackdropToContent = true,
                            ) {
                                FeedbackIssuePage(
                                    state = uiState,
                                    onTitleChange = viewModel::updateTitle,
                                    onBodyChange = viewModel::updateBody,
                                    onRefresh = viewModel::refresh,
                                    onExportZip = viewModel::requestLogExport,
                                    onClearLogs = viewModel::clearLogs,
                                    onRequestSubmit = viewModel::requestSubmit,
                                    onDismissSubmit = viewModel::dismissSubmitConfirmation,
                                    onConfirmBrowserSubmit = viewModel::submitViaBrowser,
                                    onConfirmApiSubmit = viewModel::submitViaApi,
                                    onClose = { finish() },
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        fun launch(context: Context) {
            val hostActivity = context.findHostActivity()
            val intent =
                Intent(context, FeedbackIssueActivity::class.java).apply {
                    if (hostActivity == null) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            if (hostActivity != null) {
                hostActivity.startActivity(intent)
            } else {
                context.startActivity(intent)
            }
        }
    }
}

private tailrec fun Context.findHostActivity(): Activity? =
    when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext?.findHostActivity()
        else -> null
    }
