package os.kei.ui.page.main.ba

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import os.kei.ui.page.main.ba.support.BaCalendarEntry
import os.kei.ui.page.main.ba.support.BaPageSnapshot
import os.kei.ui.page.main.ba.support.BaPoolEntry

@Immutable
internal data class BaCalendarUiState(
    val entries: List<BaCalendarEntry> = emptyList(),
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val error: String? = null,
    val lastSyncMs: Long = 0L,
)

@Immutable
internal data class BaPoolUiState(
    val entries: List<BaPoolEntry> = emptyList(),
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val error: String? = null,
    val lastSyncMs: Long = 0L,
)

@Immutable
internal data class BaCalendarPoolRouteState(
    val calendarUiState: BaCalendarUiState = BaCalendarUiState(),
    val poolUiState: BaPoolUiState = BaPoolUiState(),
)

@Immutable
internal data class BaCalendarPoolSettingsUiState(
    val snapshot: BaPageSnapshot = BaPageSnapshot(),
    val loaded: Boolean = false,
)

@Immutable
internal data class BaCalendarPoolChromeUiState(
    val serverIndex: Int = BaPageSnapshot().serverIndex,
    val serverIndexTouched: Boolean = false,
    val calendarReloadSignal: Int = 0,
    val poolReloadSignal: Int = 0,
    val showServerPopup: Boolean = false,
    val showDataSettingsSheet: Boolean = false,
    val dataRefreshIntervalDropdownExpanded: Boolean = false,
)

internal enum class BaCalendarPoolPageKind {
    Calendar,
    Pool,

    /**
     * Both lists on screen at once, which is the tablet's shape.
     *
     * Only the data-settings sheet cares: with one list showing, offering the other's "hide what has
     * ended" toggle would be a switch for something off screen, and with both showing, hiding either is
     * a switch the teacher can watch work.
     */
    Both,
}

private data class BaCalendarRequestKey(
    val isPageActive: Boolean,
    val serverIndex: Int,
    val reloadSignal: Int,
    val calendarRefreshIntervalHours: Int,
    val hydrationReady: Boolean,
)

private data class BaPoolRequestKey(
    val isPageActive: Boolean,
    val serverIndex: Int,
    val reloadSignal: Int,
    val calendarRefreshIntervalHours: Int,
    val hydrationReady: Boolean,
)

internal class BaCalendarPoolViewModel(
    application: Application,
) : AndroidViewModel(application) {
    private val appContext = application.applicationContext

    private val _calendarUiState = MutableStateFlow(BaCalendarUiState())
    val calendarUiState: StateFlow<BaCalendarUiState> = _calendarUiState.asStateFlow()

    private val _poolUiState = MutableStateFlow(BaPoolUiState())
    val poolUiState: StateFlow<BaPoolUiState> = _poolUiState.asStateFlow()

    private val _settingsUiState = MutableStateFlow(BaCalendarPoolSettingsUiState())
    val settingsUiState: StateFlow<BaCalendarPoolSettingsUiState> = _settingsUiState.asStateFlow()

    private val _chromeUiState = MutableStateFlow(BaCalendarPoolChromeUiState())
    val chromeUiState: StateFlow<BaCalendarPoolChromeUiState> = _chromeUiState.asStateFlow()

    private val _unreadCounts = MutableStateFlow(BaCalendarPoolUnreadCounts())
    val unreadCounts: StateFlow<BaCalendarPoolUnreadCounts> = _unreadCounts.asStateFlow()

    val routeState: StateFlow<BaCalendarPoolRouteState> =
        combine(calendarUiState, poolUiState) { calendar, pool ->
            BaCalendarPoolRouteState(
                calendarUiState = calendar,
                poolUiState = pool,
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
            initialValue = BaCalendarPoolRouteState(),
        )

    private var calendarJob: Job? = null
    private var poolJob: Job? = null
    private var unreadCountsJob: Job? = null
    private var lastCalendarRequestKey: BaCalendarRequestKey? = null
    private var lastPoolRequestKey: BaPoolRequestKey? = null
    private val imageWarmCoordinator =
        BaCalendarPoolImageWarmCoordinator(
            scope = viewModelScope,
            context = appContext,
        )

    init {
        viewModelScope.launch {
            val snapshot = BaCalendarPoolRepository.loadSettingsSnapshotAsync()
            _chromeUiState.update { state ->
                if (state.serverIndexTouched) {
                    state
                } else {
                    state.copy(serverIndex = snapshot.serverIndex)
                }
            }
            _settingsUiState.value =
                BaCalendarPoolSettingsUiState(
                    snapshot = snapshot,
                    loaded = true,
                )
            refreshUnreadCounts(snapshot.serverIndex)
        }
    }

    fun syncCalendar(
        isPageActive: Boolean,
        serverIndex: Int,
        reloadSignal: Int,
        calendarRefreshIntervalHours: Int,
        hydrationReady: Boolean,
    ) {
        val key =
            BaCalendarRequestKey(
                isPageActive = isPageActive,
                serverIndex = serverIndex,
                reloadSignal = reloadSignal,
                calendarRefreshIntervalHours = calendarRefreshIntervalHours,
                hydrationReady = hydrationReady,
            )
        val previousKey = lastCalendarRequestKey
        if (key == previousKey) return
        lastCalendarRequestKey = key
        calendarJob?.cancel()
        calendarJob =
            viewModelScope.launch {
                val current = _calendarUiState.value
                if (!hydrationReady) {
                    _calendarUiState.value =
                        current.copy(
                            loading = current.entries.isEmpty(),
                            refreshing = false,
                            error = null,
                        )
                    return@launch
                }
                val serverChanged = previousKey != null && previousKey.serverIndex != serverIndex
                val retainedEntries = if (serverChanged) emptyList() else current.entries
                val showLoading = retainedEntries.isEmpty()
                _calendarUiState.value =
                    current.copy(
                        entries = retainedEntries,
                        loading = showLoading,
                        refreshing = !showLoading,
                        error = null,
                    )
                val snapshot =
                    BaCalendarPoolRepository.syncCalendar(
                        context = appContext,
                        isPageActive = isPageActive,
                        serverIndex = serverIndex,
                        reloadSignal = reloadSignal,
                        calendarRefreshIntervalHours = calendarRefreshIntervalHours,
                        hydrationReady = hydrationReady,
                    )
                if (lastCalendarRequestKey != key) return@launch
                _calendarUiState.value =
                    BaCalendarUiState(
                        entries = snapshot.entries,
                        loading = snapshot.loading,
                        refreshing = false,
                        error = snapshot.error,
                        lastSyncMs = snapshot.lastSyncMs,
                    )
                refreshUnreadCounts(serverIndex)
                if (!snapshot.loading && snapshot.imageWarmEntries.isNotEmpty()) {
                    imageWarmCoordinator.scheduleCalendar(
                        serverIndex = serverIndex,
                        entries = snapshot.imageWarmEntries,
                    )
                }
            }
    }

    fun syncPool(
        isPageActive: Boolean,
        serverIndex: Int,
        reloadSignal: Int,
        calendarRefreshIntervalHours: Int,
        hydrationReady: Boolean,
    ) {
        val key =
            BaPoolRequestKey(
                isPageActive = isPageActive,
                serverIndex = serverIndex,
                reloadSignal = reloadSignal,
                calendarRefreshIntervalHours = calendarRefreshIntervalHours,
                hydrationReady = hydrationReady,
            )
        val previousKey = lastPoolRequestKey
        if (key == previousKey) return
        lastPoolRequestKey = key
        poolJob?.cancel()
        poolJob =
            viewModelScope.launch {
                val current = _poolUiState.value
                if (!hydrationReady) {
                    _poolUiState.value =
                        current.copy(
                            loading = current.entries.isEmpty(),
                            refreshing = false,
                            error = null,
                        )
                    return@launch
                }
                val serverChanged = previousKey != null && previousKey.serverIndex != serverIndex
                val retainedEntries = if (serverChanged) emptyList() else current.entries
                val showLoading = retainedEntries.isEmpty()
                _poolUiState.value =
                    current.copy(
                        entries = retainedEntries,
                        loading = showLoading,
                        refreshing = !showLoading,
                        error = null,
                    )
                val snapshot =
                    BaCalendarPoolRepository.syncPool(
                        context = appContext,
                        isPageActive = isPageActive,
                        serverIndex = serverIndex,
                        reloadSignal = reloadSignal,
                        calendarRefreshIntervalHours = calendarRefreshIntervalHours,
                        hydrationReady = hydrationReady,
                    )
                if (lastPoolRequestKey != key) return@launch
                _poolUiState.value =
                    BaPoolUiState(
                        entries = snapshot.entries,
                        loading = snapshot.loading,
                        refreshing = false,
                        error = snapshot.error,
                        lastSyncMs = snapshot.lastSyncMs,
                    )
                refreshUnreadCounts(serverIndex)
                if (!snapshot.loading && snapshot.imageWarmEntries.isNotEmpty()) {
                    imageWarmCoordinator.schedulePool(
                        serverIndex = serverIndex,
                        entries = snapshot.imageWarmEntries,
                    )
                }
            }
    }

    fun selectServer(index: Int) {
        val normalizedIndex = index.coerceIn(0, 2)
        _chromeUiState.update { state ->
            state.copy(
                serverIndex = normalizedIndex,
                serverIndexTouched = true,
                showServerPopup = false,
            )
        }
        _settingsUiState.update { state ->
            state.copy(
                snapshot = state.snapshot.copy(serverIndex = normalizedIndex),
            )
        }
        viewModelScope.launch {
            BaCalendarPoolRepository.saveServerIndexAsync(normalizedIndex)
        }
        refreshUnreadCounts(normalizedIndex)
    }

    fun requestCalendarReload() {
        _chromeUiState.update { state ->
            state.copy(calendarReloadSignal = state.calendarReloadSignal + 1)
        }
    }

    fun requestPoolReload() {
        _chromeUiState.update { state ->
            state.copy(poolReloadSignal = state.poolReloadSignal + 1)
        }
    }

    fun updateDataSettingsSheetVisible(visible: Boolean) {
        _chromeUiState.update { state ->
            if (state.showDataSettingsSheet == visible) {
                state
            } else {
                state.copy(
                    showDataSettingsSheet = visible,
                    dataRefreshIntervalDropdownExpanded =
                        if (visible) {
                            state.dataRefreshIntervalDropdownExpanded
                        } else {
                            false
                        },
                )
            }
        }
    }

    fun updateDataRefreshIntervalDropdownExpanded(expanded: Boolean) {
        _chromeUiState.update { state ->
            if (state.dataRefreshIntervalDropdownExpanded == expanded) {
                state
            } else {
                state.copy(dataRefreshIntervalDropdownExpanded = expanded)
            }
        }
    }

    fun saveRefreshInterval(
        hours: Int,
        lastSyncMs: Long,
        pageKind: BaCalendarPoolPageKind,
    ) {
        viewModelScope.launch {
            val result =
                BaCalendarPoolRepository.saveRefreshIntervalAsync(
                    hours = hours,
                    lastSyncMs = lastSyncMs,
                )
            _settingsUiState.update { state ->
                state.copy(
                    snapshot = state.snapshot.copy(calendarRefreshIntervalHours = result.hours),
                )
            }
            if (result.shouldRefresh) {
                when (pageKind) {
                    BaCalendarPoolPageKind.Calendar -> requestCalendarReload()
                    BaCalendarPoolPageKind.Pool -> requestPoolReload()
                    // Both lists are on screen, so a shortened interval has to reach both of them.
                    BaCalendarPoolPageKind.Both -> {
                        requestCalendarReload()
                        requestPoolReload()
                    }
                }
            }
        }
    }

    fun saveShowEndedActivities(enabled: Boolean) {
        viewModelScope.launch {
            BaCalendarPoolRepository.saveActivityShowEndedAsync(enabled)
            _settingsUiState.update { state ->
                state.copy(snapshot = state.snapshot.copy(showEndedActivities = enabled))
            }
        }
    }

    fun saveShowEndedPools(enabled: Boolean) {
        viewModelScope.launch {
            BaCalendarPoolRepository.savePoolShowEndedAsync(enabled)
            _settingsUiState.update { state ->
                state.copy(snapshot = state.snapshot.copy(showEndedPools = enabled))
            }
        }
    }

    fun saveShowCalendarPoolImages(enabled: Boolean) {
        viewModelScope.launch {
            BaCalendarPoolRepository.saveShowCalendarPoolImagesAsync(enabled)
            _settingsUiState.update { state ->
                state.copy(snapshot = state.snapshot.copy(showCalendarPoolImages = enabled))
            }
        }
    }

    fun updateServerPopupExpanded(expanded: Boolean) {
        _chromeUiState.update { state ->
            if (state.showServerPopup == expanded) {
                state
            } else {
                state.copy(showServerPopup = expanded)
            }
        }
    }

    fun clearServerPopup() {
        _chromeUiState.update { state ->
            if (!state.showServerPopup && !state.dataRefreshIntervalDropdownExpanded) {
                state
            } else {
                state.copy(
                    showServerPopup = false,
                    dataRefreshIntervalDropdownExpanded = false,
                )
            }
        }
    }

    fun refreshUnreadCounts(serverIndex: Int = _chromeUiState.value.serverIndex) {
        val normalizedServerIndex = serverIndex.coerceIn(0, 2)
        unreadCountsJob?.cancel()
        unreadCountsJob =
            viewModelScope.launch {
                val counts =
                    BaCalendarPoolUnreadRepository.loadCountsAsync(
                        serverIndex = normalizedServerIndex,
                    )
                if (_chromeUiState.value.serverIndex.coerceIn(0, 2) == normalizedServerIndex) {
                    _unreadCounts.value = counts
                }
            }
    }

    fun markUnreadRead(
        kind: BaCalendarPoolUnreadKind,
        serverIndex: Int = _chromeUiState.value.serverIndex,
    ) {
        val normalizedServerIndex = serverIndex.coerceIn(0, 2)
        unreadCountsJob?.cancel()
        unreadCountsJob =
            viewModelScope.launch {
                val counts =
                    BaCalendarPoolUnreadRepository.markReadAsync(
                        kind = kind,
                        serverIndex = normalizedServerIndex,
                    )
                if (_chromeUiState.value.serverIndex.coerceIn(0, 2) == normalizedServerIndex) {
                    _unreadCounts.value = counts
                }
            }
    }

    suspend fun preparePoolGuideOpen(rawUrl: String): BaPoolGuideOpenPlan =
        BaCalendarPoolRepository.preparePoolGuideOpen(rawUrl)
}
