package os.kei.ui.page.main.github.page.action

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import os.kei.R
import os.kei.core.intent.SafeExternalIntents
import os.kei.feature.github.data.remote.GITHUB_ACTIONS_APK_ARTIFACT_CONTENT_TYPE
import os.kei.feature.github.data.remote.GitHubReleaseAssetFile
import os.kei.feature.github.domain.GitHubActionsService
import os.kei.feature.github.model.GitHubActionsArtifact
import os.kei.feature.github.model.GitHubActionsWorkflowMatch
import os.kei.feature.github.model.supportsManagedApkInstall
import os.kei.ui.page.main.github.asset.GitHubAssetHandoff
import os.kei.ui.page.main.github.localizedGitHubActionsErrorMessage
import kotlin.time.Duration.Companion.milliseconds

private const val ACTIONS_ARTIFACT_PACKAGE_PROBE_TIMEOUT_MS = 2_500L
private val invalidArchiveFileNameRegex = Regex("""[\\/:*?"<>|]+""")

internal class GitHubActionsArtifactActions(
    private val env: GitHubPageActionEnvironment,
    private val actionsRepository: GitHubActionsService,
    private val assetActions: GitHubAssetActions,
    private val onDownloadHistoryChanged: suspend () -> Unit
) {
    private val context get() = env.context
    private val scope get() = env.scope
    private val state get() = env.state

    fun downloadActionsArtifact(
        runId: Long,
        artifactId: Long,
        forceExternalDownload: Boolean = false
    ) {
        val item = state.actionsTargetItem ?: return
        val workflowMatch = selectedWorkflowMatch() ?: return
        val runMatch = state.actionsRuns.firstOrNull { it.runArtifacts.run.id == runId } ?: return
        val artifactMatch = runMatch.artifactMatches.firstOrNull { it.artifact.id == artifactId } ?: return
        val artifact = artifactMatch.artifact
        if (state.lookupConfig.actionsRequireApiToken && state.lookupConfig.apiToken.trim().isBlank()) {
            env.toast(R.string.github_actions_toast_token_required)
            return
        }
        if (artifact.expired) {
            env.toast(R.string.github_actions_toast_artifact_expired)
            return
        }
        if (!runMatch.traits.completed) {
            env.toast(R.string.github_actions_toast_wait_run_completed)
            return
        }
        if (
            state.actionsArtifactDownloadLoadingId == artifact.id ||
            state.actionsArtifactShareLoadingId == artifact.id
        ) {
            return
        }
        scope.launch {
            state.actionsArtifactDownloadLoadingId = artifact.id
            try {
                val resolution = actionsRepository.resolveGitHubActionsArtifactDownloadUrl(
                    artifact = artifact,
                    owner = item.owner,
                    repo = item.repo,
                    lookupConfig = state.lookupConfig,
                    preferApiTokenRedirect = true
                ).getOrThrow()
                val resolvedUrl = SafeExternalIntents.httpsExternalUrlOrNull(resolution.downloadUrl)
                    ?: error(context.getString(R.string.github_actions_error_download_url_invalid))
                if (!forceExternalDownload && artifactMatch.supportsManagedApkInstall(state.lookupConfig)) {
                    assetActions.openManagedInstallConfirm(
                        item = item,
                        asset = artifact.toManagedInstallAsset(resolvedUrl)
                    )
                    return@launch
                }
                val fileName = artifactArchiveFileName(artifact)
                val artifactPackageNameDeferred = if (artifactMatch.traits.androidLike) {
                    async {
                        actionsRepository.probeGitHubActionsArtifactPackageName(
                            artifact = artifact,
                            resolvedDownloadUrl = resolvedUrl,
                            lookupConfig = state.lookupConfig
                        )
                    }
                } else {
                    null
                }
                if (openResolvedArtifactDownloadUrl(resolvedUrl, fileName)) {
                    val artifactPackageName = artifactPackageNameDeferred?.let { deferred ->
                        withTimeoutOrNull(ACTIONS_ARTIFACT_PACKAGE_PROBE_TIMEOUT_MS.milliseconds) {
                            deferred.await()
                        }.also { packageName ->
                            if (packageName == null) deferred.cancel()
                        }.orEmpty()
                    }.orEmpty()
                    val record = actionsRepository.buildGitHubActionsDownloadRecord(
                        owner = item.owner,
                        repo = item.repo,
                        workflow = workflowMatch.workflow,
                        run = runMatch.runArtifacts.run,
                        artifact = artifact,
                        sourceTrackId = item.id,
                        packageName = item.packageName,
                        artifactPackageName = artifactPackageName
                    )
                    actionsRepository.recordGitHubActionsArtifactDownload(record)
                    state.actionsDownloadHistory = actionsRepository.loadGitHubActionsDownloadHistory(
                        owner = item.owner,
                        repo = item.repo
                    )
                    onDownloadHistoryChanged()
                    env.toast(R.string.github_actions_toast_download_started)
                } else {
                    artifactPackageNameDeferred?.cancel()
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                env.toast(
                    context.getString(
                        R.string.github_actions_toast_download_failed,
                        localizedGitHubActionsErrorMessage(
                            context = context,
                            rawMessage = error.message ?: error.javaClass.simpleName
                        )
                    )
                )
            } finally {
                state.actionsArtifactDownloadLoadingId = null
            }
        }
    }

    fun shareActionsArtifact(runId: Long, artifactId: Long) {
        val item = state.actionsTargetItem ?: return
        val runMatch = state.actionsRuns.firstOrNull { it.runArtifacts.run.id == runId } ?: return
        val artifactMatch = runMatch.artifactMatches.firstOrNull { it.artifact.id == artifactId } ?: return
        val artifact = artifactMatch.artifact
        if (state.lookupConfig.actionsRequireApiToken && state.lookupConfig.apiToken.trim().isBlank()) {
            env.toast(R.string.github_actions_toast_token_required)
            return
        }
        if (artifact.expired) {
            env.toast(R.string.github_actions_toast_artifact_expired)
            return
        }
        if (!runMatch.traits.completed) {
            env.toast(R.string.github_actions_toast_wait_run_completed)
            return
        }
        if (
            state.actionsArtifactShareLoadingId == artifact.id ||
            state.actionsArtifactDownloadLoadingId == artifact.id
        ) {
            return
        }
        scope.launch {
            state.actionsArtifactShareLoadingId = artifact.id
            try {
                val resolution = actionsRepository.resolveGitHubActionsArtifactShareUrl(
                    artifact = artifact,
                    owner = item.owner,
                    repo = item.repo,
                    lookupConfig = state.lookupConfig
                ).getOrThrow()
                val resolvedUrl = SafeExternalIntents.httpsExternalUrlOrNull(resolution.downloadUrl)
                    ?: error(context.getString(R.string.github_actions_error_download_url_invalid))
                if (shareResolvedArtifactDownloadUrl(resolvedUrl, artifact.name)) {
                    env.toast(R.string.github_actions_toast_share_started)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                env.toast(
                    context.getString(
                        R.string.github_actions_toast_share_failed,
                        localizedGitHubActionsErrorMessage(
                            context = context,
                            rawMessage = error.message ?: error.javaClass.simpleName
                        )
                    )
                )
            } finally {
                state.actionsArtifactShareLoadingId = null
            }
        }
    }

    fun openSelectedActionsRun() {
        val run = state.actionsRuns
            .firstOrNull { it.runArtifacts.run.id == state.actionsSelectedRunId }
            ?.runArtifacts
            ?.run
            ?: return
        val url = run.htmlUrl.trim()
        if (url.isBlank()) return
        if (!SafeExternalIntents.startBrowsableUrl(context, url)) {
            env.toast(R.string.github_error_open_link)
        }
    }

    private fun selectedWorkflowMatch(): GitHubActionsWorkflowMatch? {
        val workflowId = state.actionsSelectedWorkflowId ?: return null
        return state.actionsWorkflows.firstOrNull { it.workflow.id == workflowId }
    }

    private fun openResolvedArtifactDownloadUrl(url: String, fileName: String): Boolean =
        GitHubAssetHandoff.openInDownloader(
            context = context,
            lookupConfig = state.lookupConfig,
            url = url,
            fileName = fileName,
            mimeType = "application/zip"
        ).report { messageRes -> env.toast(messageRes) }

    private fun shareResolvedArtifactDownloadUrl(url: String, artifactName: String): Boolean =
        GitHubAssetHandoff.share(
            context = context,
            lookupConfig = state.lookupConfig,
            url = url,
            subject = artifactName,
            chooserTitle = context.getString(R.string.github_actions_share_artifact_title)
        ).report { messageRes -> env.toast(messageRes) }

    private fun artifactArchiveFileName(artifact: GitHubActionsArtifact): String {
        val baseName = artifact.name
            .trim()
            .replace(invalidArchiveFileNameRegex, "_")
            .ifBlank { "artifact-${artifact.id}" }
        return if (baseName.endsWith(".zip", ignoreCase = true)) baseName else "$baseName.zip"
    }

    private fun GitHubActionsArtifact.toManagedInstallAsset(
        resolvedDownloadUrl: String
    ): GitHubReleaseAssetFile {
        return GitHubReleaseAssetFile(
            name = name.ifBlank { "actions-artifact-$id.apk" },
            downloadUrl = resolvedDownloadUrl,
            sizeBytes = sizeBytes,
            downloadCount = 0,
            contentType = GITHUB_ACTIONS_APK_ARTIFACT_CONTENT_TYPE,
            updatedAtMillis = updatedAtMillis,
            digest = digest
        )
    }
}
