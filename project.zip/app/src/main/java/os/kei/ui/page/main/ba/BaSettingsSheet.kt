@file:Suppress("FunctionName")

package os.kei.ui.page.main.ba

import android.app.Activity
import android.content.Intent
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import com.kyant.backdrop.Backdrop
import os.kei.R
import os.kei.ui.page.main.widget.glass.AppLiquidIconButton
import os.kei.ui.page.main.widget.glass.AppLiquidSearchField
import os.kei.ui.page.main.widget.glass.AppLiquidTextButton
import os.kei.ui.page.main.widget.glass.AppSwitch
import os.kei.ui.page.main.widget.glass.GlassVariant
import os.kei.ui.page.main.widget.sheet.SheetContentColumn
import os.kei.ui.page.main.widget.sheet.SheetControlRow
import os.kei.ui.page.main.widget.sheet.SheetFieldBlock
import os.kei.ui.page.main.widget.sheet.SheetSectionCard
import os.kei.ui.page.main.widget.sheet.SheetSectionHeader
import os.kei.ui.page.main.widget.sheet.SnapshotWindowBottomSheet
import os.kei.ui.page.main.widget.sheet.UnsavedSheetDismissConfirmDialog
import os.kei.ui.page.main.widget.sheet.rememberUnsavedSheetDismissHandler
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Close
import top.yukonga.miuix.kmp.icon.extended.Ok
import top.yukonga.miuix.kmp.theme.MiuixTheme

internal data class BaSettingsSheetState(
    val cafeLevel: Int,
    val mediaAdaptiveRotationEnabled: Boolean,
    val mediaSaveCustomEnabled: Boolean,
    val mediaSaveFixedTreeUri: String,
)

@Composable
internal fun BaSettingsSheet(
    show: Boolean,
    backdrop: Backdrop?,
    state: BaSettingsSheetState,
    onMediaAdaptiveRotationEnabledChange: (Boolean) -> Unit,
    onMediaSaveCustomEnabledChange: (Boolean) -> Unit,
    onMediaSaveFixedTreeUriChange: (String) -> Unit,
    debugContent: @Composable () -> Unit = {},
    hasUnsavedChanges: Boolean,
    onDismissRequest: () -> Unit,
    onSaveRequest: () -> Unit,
) {
    val context = LocalContext.current
    val settingsAccent = Color(0xFF3B82F6)
    val pickMediaSaveFolderLauncher =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
            val treeUri = result.data?.data ?: return@rememberLauncherForActivityResult
            runCatching {
                val persistableFlags =
                    (result.data?.flags ?: 0) and
                        (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                if (persistableFlags and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0) {
                    context.contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                if (persistableFlags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0) {
                    context.contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                }
            }
            onMediaSaveFixedTreeUriChange(treeUri.toString())
        }
    val dismissHandler =
        rememberUnsavedSheetDismissHandler(
            hasUnsavedChanges = hasUnsavedChanges,
            onDismissRequest = onDismissRequest,
        )

    SnapshotWindowBottomSheet(
        show = show,
        title = stringResource(R.string.ba_settings_title),
        onDismissRequest = dismissHandler.requestDismiss,
        allowDismiss = dismissHandler.allowDismiss,
        onBlockedDismissRequest = dismissHandler.requestDismiss,
        startAction = {
            AppLiquidIconButton(
                backdrop = backdrop,
                icon = MiuixIcons.Regular.Close,
                contentDescription = stringResource(R.string.common_close),
                variant = GlassVariant.Bar,
                onClick = dismissHandler.requestDismiss,
            )
        },
        endAction = {
            AppLiquidIconButton(
                backdrop = backdrop,
                icon = MiuixIcons.Regular.Ok,
                contentDescription = stringResource(R.string.common_save),
                variant = GlassVariant.Bar,
                onClick = onSaveRequest,
            )
        },
    ) {
        SheetContentColumn(verticalSpacing = 14.dp) {
            SheetSectionHeader(stringResource(R.string.ba_settings_section_media))
            SheetSectionCard {
                Text(
                    text = stringResource(R.string.ba_settings_card_media_title),
                    color = settingsAccent,
                )
                SheetControlRow(
                    label = stringResource(R.string.ba_settings_label_media_adaptive_rotation),
                    summary = stringResource(R.string.ba_settings_summary_media_adaptive_rotation),
                ) {
                    AppSwitch(
                        checked = state.mediaAdaptiveRotationEnabled,
                        onCheckedChange = onMediaAdaptiveRotationEnabledChange,
                    )
                }
                SheetControlRow(
                    label = stringResource(R.string.ba_settings_label_media_save_custom),
                    summary = stringResource(R.string.ba_settings_summary_media_save_custom),
                ) {
                    AppSwitch(
                        checked = state.mediaSaveCustomEnabled,
                        onCheckedChange = onMediaSaveCustomEnabledChange,
                    )
                }
                if (state.mediaSaveCustomEnabled) {
                    SheetFieldBlock(
                        title = stringResource(R.string.ba_settings_label_media_save_fixed_uri),
                        summary =
                            if (state.mediaSaveFixedTreeUri.isBlank()) {
                                stringResource(R.string.ba_settings_summary_media_save_fixed_uri_empty)
                            } else {
                                stringResource(R.string.ba_settings_summary_media_save_fixed_uri_ready)
                            },
                        trailing = {
                            AppLiquidTextButton(
                                backdrop = backdrop,
                                variant = GlassVariant.SheetPrimaryAction,
                                textColor = Color(0xFF3B82F6),
                                text = stringResource(R.string.ba_settings_action_pick_media_save_location),
                                onClick = {
                                    val currentTreeUri =
                                        state.mediaSaveFixedTreeUri
                                            .takeIf { it.isNotBlank() }
                                            ?.let { raw -> runCatching { raw.toUri() }.getOrNull() }
                                    val pickerIntent =
                                        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                                            addFlags(
                                                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION,
                                            )
                                            putExtra(
                                                DocumentsContract.EXTRA_INITIAL_URI,
                                                currentTreeUri
                                                    ?: "content://com.android.externalstorage.documents/tree/primary%3ADownload".toUri(),
                                            )
                                        }
                                    pickMediaSaveFolderLauncher.launch(pickerIntent)
                                },
                            )
                        },
                    ) {
                        AppLiquidSearchField(
                            modifier = Modifier.fillMaxWidth(),
                            value = state.mediaSaveFixedTreeUri,
                            onValueChange = { onMediaSaveFixedTreeUriChange(it.trim()) },
                            label = stringResource(R.string.ba_settings_hint_media_save_fixed_uri),
                            backdrop = backdrop,
                            variant = GlassVariant.SheetInput,
                            singleLine = true,
                            textAlign = TextAlign.Start,
                            fontSize = 14.sp,
                        )
                    }
                }
            }
            debugContent()
        }
    }
    UnsavedSheetDismissConfirmDialog(
        show = dismissHandler.showConfirmDialog,
        onKeepEditing = dismissHandler.keepEditing,
        onDiscardChanges = dismissHandler.discardChanges,
    )
}
