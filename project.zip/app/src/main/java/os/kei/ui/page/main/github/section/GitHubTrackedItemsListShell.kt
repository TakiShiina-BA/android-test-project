package os.kei.ui.page.main.github.section

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import os.kei.BuildConfig
import os.kei.R
import os.kei.feature.github.model.forTrackedItem
import os.kei.feature.github.model.isKeiOsSelfTrack
import os.kei.ui.page.main.github.AppIconImage
import os.kei.ui.page.main.github.GitHubStatusPalette
import os.kei.ui.page.main.github.LocalGitHubAppIconBitmaps
import os.kei.ui.page.main.github.VersionCheckUi
import os.kei.ui.page.main.github.asset.formatReleaseUpdatedAtCompact
import os.kei.ui.page.main.github.asset.formatReleaseUpdatedAtNoYear
import os.kei.ui.page.main.github.githubReleaseHintMessage
import os.kei.ui.page.main.github.githubTrackedDisplaySubtitle
import os.kei.ui.page.main.github.githubTrackedDisplayTitle
import os.kei.ui.page.main.widget.core.AppInfoListBody
import os.kei.ui.page.main.widget.core.AppStatusPillSize
import os.kei.ui.page.main.widget.core.AppSupportingBlock
import os.kei.ui.page.main.widget.core.CardLayoutRhythm
import os.kei.ui.page.main.widget.core.MiuixInfoItem
import os.kei.ui.page.main.widget.glass.AppLiquidAccordionCard
import os.kei.ui.page.main.widget.status.StatusPill
import os.kei.ui.testing.KeiOsTestTags
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Suppress("FunctionName")
@OptIn(ExperimentalLayoutApi::class)
internal fun LazyListScope.GitHubTrackedItemsListShell(
    content: GitHubTrackedItemsContent,
    surfaces: GitHubTrackedItemsSurfaces,
    checkState: GitHubTrackedItemsCheckState,
    assetState: GitHubTrackedItemsAssetState,
    expansionState: GitHubTrackedItemsExpansionState,
    runtime: GitHubTrackedItemsRuntime,
    actions: GitHubTrackedItemsActions,
) {
    val context = runtime.context
    if (content.trackedItems.isEmpty()) {
        if (content.showListStatus) {
            item {
                MiuixInfoItem(
                    stringResource(R.string.github_list_label_track_list),
                    stringResource(R.string.github_list_msg_empty),
                )
            }
        }
    } else if (content.filteredTracked.isEmpty()) {
        if (content.showListStatus) {
            item {
                MiuixInfoItem(
                    stringResource(R.string.github_list_label_search_result),
                    stringResource(R.string.github_list_msg_no_match),
                )
            }
        }
    } else {
        items(
            // This lane's cards. One column and the lane is the whole list; a wide window splits it, and
            // which half a card is in is decided by `githubTrackedLanesFor`, not here.
            items = content.laneTracked,
            key = { it.id },
            contentType = { "tracked_app" },
        ) { item ->
            val expanded = expansionState.trackedCardExpanded[item.id] == true
            val state = checkState.checkStates[item.id] ?: pendingVersionCheckUi(context)
            val itemLookupConfig = content.lookupConfig.forTrackedItem(item)
            val installedAppLabel = content.installedAppLabelsByPackage[item.packageName.trim()].orEmpty()
            val displayTitle =
                item.githubTrackedDisplayTitle(
                    state = state,
                    installedAppLabel = installedAppLabel,
                )
            val displaySubtitle = item.githubTrackedDisplaySubtitle(state, displayTitle)
            AppLiquidAccordionCard(
                // The profile's handle on a tracked card. Only the first one carries it: a per-item tag
                // would put a resource id on every card in the list for one journey's benefit.
                modifier =
                    if (content.sortedTracked.firstOrNull()?.id == item.id) {
                        Modifier.testTag(KeiOsTestTags.GitHubTrackedItemCardFirst)
                    } else {
                        Modifier
                    },
                backdrop = surfaces.contentBackdrop,
                title = displayTitle,
                subtitle = displaySubtitle,
                expanded = expanded,
                onExpandedChange = {
                    actions.onTrackedCardExpandedChange(item.id, it)
                    if (!it) {
                        val collapseState = checkState.checkStates[item.id] ?: VersionCheckUi()
                        actions.onCollapseTrackedCard(item, collapseState)
                    }
                },
                headerStartAction = {
                    val appIconBitmaps = LocalGitHubAppIconBitmaps.current
                    val packageName = item.packageName.trim()
                    AppIconImage(
                        packageName = packageName,
                        bitmap = appIconBitmaps[packageName],
                        size = 24.dp,
                    )
                },
                titleAccessory = {
                    if (item.isKeiOsSelfTrack(packageName = BuildConfig.APPLICATION_ID)) {
                        StatusPill(
                            label = stringResource(R.string.github_track_badge_current_app),
                            color = GitHubStatusPalette.Active,
                            size = AppStatusPillSize.Compact,
                        )
                    }
                },
                onHeaderLongClick = { actions.onOpenTrackSheetForEdit(item) },
                clipContent = false,
                headerContentPadding = githubTrackedCardHeaderPadding,
                headerHorizontalSpacing = githubTrackedCardHeaderHorizontalSpacing,
                headerActionSpacing = githubTrackedCardHeaderActionSpacing,
                headerActions = {
                    GitHubTrackedItemHeaderActions(
                        item = item,
                        state = state,
                        displayTitle = displayTitle,
                        lookupConfig = content.lookupConfig,
                        checkState = checkState,
                        assetState = assetState,
                        pinned = item.id in content.pinnedTrackIds,
                        actions = actions,
                        context = context,
                    )
                },
            ) {
                AppInfoListBody(
                    modifier = Modifier.fillMaxWidth(),
                    verticalSpacing = CardLayoutRhythm.denseSectionGap,
                ) {
                    if (item.externalBuildUntilRelease) {
                        val checkedAt =
                            formatReleaseUpdatedAtNoYear(
                                state.checkedAtMillis.takeIf { it > 0L },
                            )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            StatusPill(
                                label =
                                    stringResource(
                                        if (!state.loading && !state.hasStableRelease && state.latestPreRawTag.isBlank()) {
                                            R.string.github_track_badge_waiting_release
                                        } else {
                                            R.string.github_track_badge_external_build
                                        },
                                    ),
                                color = GitHubStatusPalette.Cache,
                                size = AppStatusPillSize.Compact,
                            )
                            checkedAt?.let { timestamp ->
                                StatusPill(
                                    label = timestamp,
                                    color = GitHubStatusPalette.Active,
                                    size = AppStatusPillSize.Compact,
                                )
                            }
                        }
                    }
                    GitHubRepositoryLinkCard(
                        item = item,
                        state = state,
                        onOpenExternalUrl = actions.onOpenExternalUrl,
                    )
                    val appUpdatedAtLabel =
                        formatReleaseUpdatedAtCompact(
                            content.appLastUpdatedAtByTrackId[item.id]?.takeIf { it > 0L },
                        ) ?: stringResource(R.string.common_unknown)
                    GitHubTrackedItemVersionSections(
                        item = item,
                        state = state,
                        itemLookupConfig = itemLookupConfig,
                        appUpdatedAtLabel = appUpdatedAtLabel,
                        checkState = checkState,
                        expansionState = expansionState,
                        actions = actions,
                        context = context,
                    )
                    if (state.releaseHint.isNotBlank()) {
                        AppSupportingBlock(
                            text = githubReleaseHintMessage(context, state.releaseHint),
                            accentColor = MiuixTheme.colorScheme.onBackgroundVariant,
                        )
                    }
                    GitHubTrackedItemAssetSections(
                        item = item,
                        state = state,
                        itemLookupConfig = itemLookupConfig,
                        content = content,
                        surfaces = surfaces,
                        assetState = assetState,
                        runtime = runtime,
                        actions = actions,
                    )
                }
            }
        }
    }
}

internal val githubTrackedCardHeaderPadding =
    PaddingValues(
        horizontal = CardLayoutRhythm.cardHorizontalPadding,
        vertical = 4.dp,
    )

internal val githubTrackedCardHeaderHorizontalSpacing = 4.dp
internal val githubTrackedCardHeaderActionSpacing = 0.dp
