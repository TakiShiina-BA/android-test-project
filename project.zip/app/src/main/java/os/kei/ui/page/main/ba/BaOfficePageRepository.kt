package os.kei.ui.page.main.ba

import kotlinx.coroutines.withContext
import os.kei.core.concurrency.AppDispatchers
import os.kei.ui.page.main.ba.support.BaAccountId
import os.kei.ui.page.main.ba.support.BaAccountProfileInput
import os.kei.ui.page.main.ba.support.BaAccountStoreSnapshot
import os.kei.ui.page.main.ba.support.BaDailyDoneConfig
import os.kei.ui.page.main.ba.support.BaPageSnapshot
import os.kei.ui.page.main.ba.support.currentArenaRefreshSlotMs
import os.kei.ui.page.main.ba.support.currentCafeStudentRefreshSlotMs

internal data class BaOfficeServerRestorePersistenceResult(
    val serverIndex: Int,
)

internal data class BaOfficeSettingsSavePersistenceResult(
    val persisted: BaSettingsPersistenceResult,
)

internal data class BaOfficeNotificationSavePersistenceResult(
    val persisted: BaNotificationSettingsPersistenceResult,
    val savedDraft: BaPageNotificationDraftState,
    val resetCafeApLastNotifiedLevel: Boolean,
    val arenaRefreshLastNotifiedSlotMs: Long?,
    val cafeVisitLastNotifiedSlotMs: Long?,
)

internal open class BaOfficePageRepository(
    private val clock: BaOfficeClock = BaSystemOfficeClock,
) {
    open suspend fun loadInitialSnapshot(): BaPageSnapshot = BaOfficeRepository.loadSnapshotAsync()

    open suspend fun loadAccountState(): BaAccountStoreSnapshot = BaOfficeRepository.loadAccountStateAsync()

    suspend fun selectActiveAccount(accountId: BaAccountId): BaPageSnapshot? =
        BaOfficeRepository.selectActiveAccountAsync(accountId)

    suspend fun saveAllAccountsFollowGlobalNotificationSettings(enabled: Boolean): BaAccountStoreSnapshot =
        BaOfficeRepository.saveAllAccountsFollowGlobalNotificationSettingsAsync(enabled)

    suspend fun saveAccountEnabled(
        accountId: BaAccountId,
        enabled: Boolean,
    ): BaAccountStoreSnapshot =
        BaOfficeRepository.saveAccountEnabledAsync(
            accountId = accountId,
            enabled = enabled,
        )

    suspend fun addAccount(input: BaAccountProfileInput): BaAccountStoreSnapshot =
        BaOfficeRepository.addAccountAsync(input)

    suspend fun updateAccountProfile(
        accountId: BaAccountId,
        input: BaAccountProfileInput,
    ): BaAccountStoreSnapshot =
        BaOfficeRepository.updateAccountProfileAsync(
            accountId = accountId,
            input = input,
        )

    suspend fun deleteAccount(accountId: BaAccountId): BaAccountStoreSnapshot =
        BaOfficeRepository.deleteAccountAsync(accountId)

    suspend fun moveAccount(
        accountId: BaAccountId,
        offset: Int,
    ): BaAccountStoreSnapshot =
        BaOfficeRepository.moveAccountAsync(accountId = accountId, offset = offset)

    suspend fun clearListScrollState() {
        BaOfficeRepository.clearListScrollStateAsync()
    }

    open suspend fun saveCraftCardExpanded(expanded: Boolean) {
        BaOfficeRepository.saveCraftCardExpandedAsync(expanded)
    }

    open suspend fun loadDailyDoneConfig(): BaDailyDoneConfig = BaOfficeRepository.loadDailyDoneConfigAsync()

    open suspend fun saveDailyDoneConfig(config: BaDailyDoneConfig) {
        BaOfficeRepository.saveDailyDoneConfigAsync(config)
    }

    suspend fun restoreServerSelection(currentServerIndex: Int): BaOfficeServerRestorePersistenceResult? =
        withContext(AppDispatchers.baFetch) {
            val savedServerIndex = BaOfficeRepository.loadServerIndex()
            if (savedServerIndex == currentServerIndex) {
                return@withContext null
            }
            BaOfficeServerRestorePersistenceResult(
                serverIndex = savedServerIndex,
            )
        }

    suspend fun persistSettings(sheetState: BaSettingsSheetState): BaOfficeSettingsSavePersistenceResult =
        withContext(AppDispatchers.baFetch) {
            BaOfficeSettingsSavePersistenceResult(
                persisted = BaSettingsPersistenceRepository.persistSettingsDraft(sheetState),
            )
        }

    open suspend fun persistNotificationSettings(
        sheetState: BaNotificationSettingsSheetState,
        previousCafeApNotifyEnabled: Boolean,
        previousCafeApNotifyThreshold: Int,
        previousArenaRefreshNotifyEnabled: Boolean,
        previousCafeVisitNotifyEnabled: Boolean,
        serverIndex: Int,
    ): BaOfficeNotificationSavePersistenceResult =
        withContext(AppDispatchers.baFetch) {
            val persisted = BaSettingsPersistenceRepository.persistNotificationSettingsDraft(sheetState)
            val resetCafeApLastNotifiedLevel =
                !persisted.cafeApNotifyEnabled ||
                    previousCafeApNotifyThreshold != persisted.savedCafeApThreshold ||
                    !previousCafeApNotifyEnabled
            if (resetCafeApLastNotifiedLevel) {
                BaSettingsPersistenceRepository.resetCafeApLastNotifiedLevel()
            }
            val nowMs = clock.nowMs()
            val arenaRefreshSlot =
                when {
                    !persisted.arenaRefreshNotifyEnabled -> {
                        BaSettingsPersistenceRepository.resetArenaRefreshLastNotifiedSlot()
                        0L
                    }

                    !previousArenaRefreshNotifyEnabled -> {
                        currentArenaRefreshSlotMs(
                            nowMs = nowMs,
                            serverIndex = serverIndex,
                        ).also(BaSettingsPersistenceRepository::saveArenaRefreshLastNotifiedSlot)
                    }

                    else -> {
                        null
                    }
                }
            val cafeVisitSlot =
                when {
                    !persisted.cafeVisitNotifyEnabled -> {
                        BaSettingsPersistenceRepository.resetCafeVisitLastNotifiedSlot()
                        0L
                    }

                    !previousCafeVisitNotifyEnabled -> {
                        currentCafeStudentRefreshSlotMs(
                            nowMs = nowMs,
                            serverIndex = serverIndex,
                        ).also(BaSettingsPersistenceRepository::saveCafeVisitLastNotifiedSlot)
                    }

                    else -> {
                        null
                    }
                }
            BaOfficeNotificationSavePersistenceResult(
                persisted = persisted,
                savedDraft = sheetState.toSavedDraft(persisted),
                resetCafeApLastNotifiedLevel = resetCafeApLastNotifiedLevel,
                arenaRefreshLastNotifiedSlotMs = arenaRefreshSlot,
                cafeVisitLastNotifiedSlotMs = cafeVisitSlot,
            )
        }

}

private fun BaNotificationSettingsSheetState.toSavedDraft(
    persisted: BaNotificationSettingsPersistenceResult,
): BaPageNotificationDraftState =
    BaPageNotificationDraftState(
        apNotifyEnabled = apNotifyEnabled,
        cafeApNotifyEnabled = persisted.cafeApNotifyEnabled,
        keepApRemindersReadUntilBelowThreshold =
            persisted.keepApRemindersReadUntilBelowThreshold,
        arenaRefreshNotifyEnabled = persisted.arenaRefreshNotifyEnabled,
        cafeVisitNotifyEnabled = persisted.cafeVisitNotifyEnabled,
        craftNotifyEnabled = persisted.craftNotifyEnabled,
        calendarUpcomingNotifyEnabled = persisted.calendarUpcomingNotifyEnabled,
        calendarEndingNotifyEnabled = persisted.calendarEndingNotifyEnabled,
        poolUpcomingNotifyEnabled = persisted.poolUpcomingNotifyEnabled,
        poolEndingNotifyEnabled = persisted.poolEndingNotifyEnabled,
        calendarPoolChangeNotifyEnabled = persisted.calendarPoolChangeNotifyEnabled,
        calendarPoolNotifyLeadHours = persisted.calendarPoolNotifyLeadHours,
        apNotifyThresholdText = persisted.savedThreshold.toString(),
        cafeApNotifyThresholdText = persisted.savedCafeApThreshold.toString(),
    )
