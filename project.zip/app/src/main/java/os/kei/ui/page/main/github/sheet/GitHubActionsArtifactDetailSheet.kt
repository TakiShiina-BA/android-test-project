@file:Suppress("FunctionName")

package os.kei.ui.page.main.github.sheet

import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import os.kei.R
import os.kei.core.ext.showToast
import os.kei.feature.github.data.remote.GitHubReleaseAssetFile
import os.kei.ui.page.main.github.GitHubApkTrustReason
import os.kei.ui.page.main.github.GitHubDecisionLevel
import os.kei.ui.page.main.github.GitHubStatusPalette
import os.kei.ui.page.main.github.asset.formatAssetSize
import os.kei.ui.page.main.github.asset.formatReleaseUpdatedAtNoYear
import os.kei.ui.page.main.github.buildGitHubApkTrustSignal
import os.kei.ui.page.main.github.page.GitHubActionsArtifactDetailRequest
import os.kei.ui.page.main.os.appLucideCloseIcon
import os.kei.ui.page.main.os.appLucideDownloadIcon
import os.kei.ui.page.main.os.appLucidePackageIcon
import os.kei.ui.page.main.os.appLucideRefreshIcon
import os.kei.ui.page.main.os.appLucideShareIcon
import os.kei.ui.page.main.os.osLucideCopyIcon
import os.kei.ui.page.main.widget.glass.AppLiquidIconButton
import os.kei.ui.page.main.widget.glass.GlassVariant
import os.kei.ui.page.main.widget.sheet.SheetContentColumn
import os.kei.ui.page.main.widget.sheet.SheetSectionCard
import os.kei.ui.page.main.widget.sheet.SheetSectionHeader
import os.kei.ui.page.main.widget.sheet.SheetSummaryCard
import os.kei.ui.page.main.widget.sheet.SnapshotWindowBottomSheet

@Composable
internal fun GitHubActionsArtifactDetailSheet(
    request: GitHubActionsArtifactDetailRequest?,
    backdrop: Backdrop,
    hasToken: Boolean,
    managedInstallEnabled: Boolean,
    downloading: Boolean,
    sharing: Boolean,
    onDismissRequest: () -> Unit,
    onRefreshRun: (Long) -> Unit,
    onInstall: (Long, Long) -> Unit,
    onDownload: (Long, Long) -> Unit,
    onShare: (Long, Long) -> Unit,
) {
    val detail = request ?: return
    val run = detail.runMatch.runArtifacts.run
    val artifact = detail.artifactMatch.artifact
    val context = LocalContext.current
    val trustSignal =
        buildGitHubApkTrustSignal(
            asset =
                GitHubReleaseAssetFile(
                    name = artifact.name,
                    downloadUrl = artifact.archiveDownloadUrl,
                    sizeBytes = artifact.sizeBytes,
                    downloadCount = 0,
                    updatedAtMillis = artifact.updatedAtMillis,
                ),
            supportedAbis = Build.SUPPORTED_ABIS.toList(),
        )
    val busy = downloading || sharing
    val canAct = hasToken && detail.runMatch.traits.completed && !artifact.expired && !busy
    val artifactSizeLabel =
        artifact.sizeBytes
            .takeIf { it > 0L }
            ?.let { formatAssetSize(it, context) }
            ?: stringResource(R.string.common_unknown)
    val actionButtonSize = 54.dp
    val copyMetadataDescription = stringResource(R.string.github_actions_action_copy_metadata)
    val downloadActionDescription =
        stringResource(
            R.string.github_actions_action_with_size,
            stringResource(R.string.common_download),
            artifactSizeLabel,
        )
    SnapshotWindowBottomSheet(
        show = true,
        preferExportedBackdrop = true,
        title = stringResource(R.string.github_actions_artifact_detail_title),
        onDismissRequest = onDismissRequest,
        startAction = {
            AppLiquidIconButton(
                backdrop = backdrop,
                variant = GlassVariant.Bar,
                icon = appLucideCloseIcon(),
                contentDescription = stringResource(R.string.common_close),
                onClick = onDismissRequest,
            )
        },
        endAction = {
            AppLiquidIconButton(
                backdrop = backdrop,
                variant = GlassVariant.Bar,
                icon = appLucideRefreshIcon(),
                contentDescription = stringResource(R.string.common_refresh),
                onClick = { onRefreshRun(run.id) },
            )
        },
    ) {
        SheetContentColumn(verticalSpacing = 14.dp) {
            SheetSummaryCard(
                title = artifact.name,
                badgeLabel = stringResource(trustSignal.level.labelRes()),
                badgeColor = trustSignal.level.statusColor(),
            ) {
                GitHubDecisionDetailTextLine(
                    stringResource(
                        R.string.github_actions_artifact_detail_score,
                        detail.artifactMatch.score,
                    ),
                )
                GitHubDecisionDetailTextLine(
                    stringResource(
                        R.string.github_actions_artifact_detail_run,
                        run.displayName,
                        run.headBranch.ifBlank { stringResource(R.string.common_unknown) },
                    ),
                )
                GitHubDecisionDetailTextLine(
                    artifactSizeLabel,
                )
                artifact.expiresAtMillis?.let { expiresAt ->
                    GitHubDecisionDetailTextLine(
                        stringResource(
                            R.string.github_actions_artifact_detail_expires_at,
                            formatReleaseUpdatedAtNoYear(expiresAt)
                                ?: stringResource(R.string.common_unknown),
                        ),
                    )
                }
                artifact.workflowRunHeadSha
                    .ifBlank { run.headSha }
                    .takeIf { it.isNotBlank() }
                    ?.let { sha ->
                        GitHubDecisionDetailTextLine(
                            stringResource(
                                R.string.github_actions_artifact_detail_commit,
                                sha.take(12),
                            ),
                        )
                    }
            }
            TrustReasonSection(
                reasons = trustSignal.reasons,
                context = context,
            )
            ArtifactSelectorReasonSection(detail.artifactMatch.reasons)
            SheetSectionCard {
                val copyPayload =
                    buildArtifactCopyPayload(
                        runHeadSha = run.headSha,
                        artifactHeadSha = artifact.workflowRunHeadSha,
                    )
                val copyToast =
                    stringResource(R.string.github_actions_toast_artifact_metadata_copied)
                ActionButtonRow {
                    AppLiquidIconButton(
                        backdrop = backdrop,
                        variant = GlassVariant.SheetAction,
                        icon = osLucideCopyIcon(),
                        contentDescription = copyMetadataDescription,
                        enabled = copyPayload.isNotBlank(),
                        width = actionButtonSize,
                        height = actionButtonSize,
                        onClick = {
                            copyTextToClipboard(context, "github_artifact_metadata", copyPayload)
                            context.showToast(copyToast)
                        },
                    )
                    if (managedInstallEnabled) {
                        AppLiquidIconButton(
                            backdrop = backdrop,
                            variant = GlassVariant.SheetAction,
                            icon = appLucidePackageIcon(),
                            contentDescription =
                                stringResource(
                                    if (downloading) {
                                        R.string.github_apk_info_action_installing
                                    } else {
                                        R.string.github_page_install_status_install
                                    },
                                ),
                            enabled = canAct,
                            width = actionButtonSize,
                            height = actionButtonSize,
                            onClick = { onInstall(run.id, artifact.id) },
                        )
                    }
                    AppLiquidIconButton(
                        backdrop = backdrop,
                        variant = GlassVariant.SheetAction,
                        icon = appLucideDownloadIcon(),
                        contentDescription = downloadActionDescription,
                        enabled = canAct,
                        width = actionButtonSize,
                        height = actionButtonSize,
                        onClick = { onDownload(run.id, artifact.id) },
                    )
                    AppLiquidIconButton(
                        backdrop = backdrop,
                        variant = GlassVariant.SheetAction,
                        icon = appLucideShareIcon(),
                        contentDescription = stringResource(R.string.github_actions_action_share),
                        enabled = canAct,
                        width = actionButtonSize,
                        height = actionButtonSize,
                        onClick = { onShare(run.id, artifact.id) },
                    )
                }
            }
        }
    }
}

private fun buildArtifactCopyPayload(
    runHeadSha: String,
    artifactHeadSha: String,
): String =
    buildList {
        artifactHeadSha.ifBlank { runHeadSha }.takeIf { it.isNotBlank() }?.let { sha ->
            add("commit: $sha")
        }
    }.joinToString("\n")

@Composable
private fun TrustReasonSection(
    reasons: List<GitHubApkTrustReason>,
    context: Context,
) {
    SheetSectionHeader(stringResource(R.string.github_apk_trust_detail_reason_title))
    SheetSectionCard {
        if (reasons.isEmpty()) {
            GitHubDecisionDetailTextLine(stringResource(R.string.github_apk_trust_detail_reason_empty))
        } else {
            reasons.forEach { reason ->
                GitHubDecisionDetailTextLine(context.getString(reason.labelRes()))
            }
        }
    }
}

@Composable
private fun ArtifactSelectorReasonSection(reasons: List<String>) {
    SheetSectionHeader(stringResource(R.string.github_actions_artifact_detail_selector_title))
    SheetSectionCard {
        if (reasons.isEmpty()) {
            GitHubDecisionDetailTextLine(stringResource(R.string.github_actions_artifact_detail_selector_empty))
        } else {
            reasons.take(6).forEach { reason ->
                GitHubDecisionDetailTextLine(reason)
            }
        }
    }
}

@Composable
private fun ActionButtonRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
        content = content,
    )
}

private fun GitHubDecisionLevel.statusColor(): Color =
    when (this) {
        GitHubDecisionLevel.Good -> GitHubStatusPalette.Update
        GitHubDecisionLevel.Review -> GitHubStatusPalette.Cache
        GitHubDecisionLevel.Risk -> GitHubStatusPalette.Error
    }

private fun GitHubDecisionLevel.labelRes(): Int =
    when (this) {
        GitHubDecisionLevel.Good -> R.string.github_apk_trust_good
        GitHubDecisionLevel.Review -> R.string.github_apk_trust_review
        GitHubDecisionLevel.Risk -> R.string.github_apk_trust_risk
    }

private fun GitHubApkTrustReason.labelRes(): Int =
    when (this) {
        GitHubApkTrustReason.PreferredAbi -> R.string.github_apk_trust_reason_preferred_abi
        GitHubApkTrustReason.UniversalAsset -> R.string.github_apk_trust_reason_universal
        GitHubApkTrustReason.IncompatibleAbi -> R.string.github_apk_trust_reason_incompatible
        GitHubApkTrustReason.DebugBuild -> R.string.github_apk_trust_reason_debug
        GitHubApkTrustReason.UnsignedBuild -> R.string.github_apk_trust_reason_unsigned
        GitHubApkTrustReason.SourceArchive -> R.string.github_apk_trust_reason_source
        GitHubApkTrustReason.ApkLike -> R.string.github_apk_trust_reason_apk
        GitHubApkTrustReason.UnknownFormat -> R.string.github_apk_trust_reason_unknown_format
    }
