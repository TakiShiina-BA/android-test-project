package os.kei.ui.page.main.github

import android.content.Context
import os.kei.R
import os.kei.feature.github.domain.GitHubRepositoryDiscoveryHttpException
import os.kei.feature.github.model.GitHubTrackedReleaseStatus

private val githubPageHttpStatusRegex = Regex("""HTTP\s+(\d{3})""", RegexOption.IGNORE_CASE)

internal fun localizedGitHubActionsErrorMessage(
    context: Context,
    rawMessage: String?
): String {
    val message = rawMessage?.trim().orEmpty()
    if (message.isBlank()) return context.getString(R.string.common_unknown)
    val lower = message.lowercase()
    return when {
        message == "A GitHub token is required to download Actions artifacts" ||
            message == "GitHub Actions API Token mode requires a token" ||
            message == LEGACY_ACTIONS_DOWNLOAD_TOKEN_REQUIRED ||
            message == LEGACY_ACTIONS_API_TOKEN_REQUIRED ->
            context.getString(R.string.github_actions_error_detail_token_required)

        message == "The artifact is missing a download URL and repository information" ||
            message == "The artifact is missing a nightly.link download URL" ||
            message == LEGACY_ARTIFACT_MISSING_DOWNLOAD ->
            context.getString(R.string.github_actions_error_detail_artifact_missing_download)

        message == "GitHub Actions artifact download returned no redirect URL" ||
            message == LEGACY_ARTIFACT_NO_REDIRECT ->
            context.getString(R.string.github_actions_error_detail_artifact_no_redirect)

        message.startsWith("GitHub public API found no matching workflow:") ||
            message.startsWith(LEGACY_WORKFLOW_NOT_FOUND_PREFIX) -> {
            val workflowId = message.substringAfterLast(':')
                .substringAfterLast('\uff1a')
                .trim()
                .ifBlank { context.getString(R.string.common_unknown) }
            context.getString(R.string.github_actions_error_detail_workflow_not_found, workflowId)
        }

        message == "GitHub Actions token is invalid or expired" ||
            message == LEGACY_ACTIONS_TOKEN_INVALID ->
            context.getString(R.string.github_actions_error_detail_token_invalid)

        message.startsWith("GitHub Actions guest API is rate limited") ||
            message.startsWith(LEGACY_ACTIONS_GUEST_RATE_LIMITED_PREFIX) ->
            context.getString(R.string.github_actions_error_detail_guest_rate_limited)

        message == "GitHub Actions API is rate limited" ||
            message == LEGACY_ACTIONS_API_RATE_LIMITED ->
            context.getString(R.string.github_actions_error_detail_api_rate_limited)

        message.startsWith("GitHub Actions API access was denied") ||
            message.startsWith(LEGACY_ACTIONS_API_FORBIDDEN_PREFIX) -> {
            val suffix = message
                .substringAfter("denied", "")
                .ifBlank { message.substringAfter(LEGACY_ACTIONS_API_FORBIDDEN_PREFIX, "") }
            context.getString(R.string.github_actions_error_detail_api_forbidden, suffix)
        }

        message == "The repository or GitHub Actions resource does not exist, or the current token lacks access" ||
            message == LEGACY_ACTIONS_RESOURCE_MISSING ->
            context.getString(R.string.github_actions_error_detail_resource_missing)

        message == "The GitHub Actions artifact has expired" ||
            message == LEGACY_ACTIONS_ARTIFACT_EXPIRED ->
            context.getString(R.string.github_actions_error_detail_artifact_expired)

        message.startsWith("nightly.link cannot directly download raw APK artifact") ||
            message.startsWith(LEGACY_NIGHTLY_RAW_ARTIFACT_PREFIX) -> {
            val name = message
                .substringAfter("artifact", "")
                .substringAfter(':', "")
                .substringAfter('\uff1a', "")
                .substringBefore('.')
                .substringBefore('\u3002')
                .trim()
                .ifBlank { "artifact" }
            context.getString(R.string.github_actions_error_detail_nightly_raw_artifact, name)
        }

        message == "nightly.link did not read workflow artifacts" ||
            message == LEGACY_NIGHTLY_NO_WORKFLOW_ARTIFACT ->
            context.getString(R.string.github_actions_error_detail_nightly_no_workflow_artifact)

        message.startsWith("nightly.link did not read downloadable artifacts") ||
            message.startsWith(LEGACY_NIGHTLY_NO_DOWNLOADABLE_ARTIFACTS_PREFIX) ->
            context.getString(R.string.github_actions_error_detail_nightly_no_downloadable_artifacts)

        lower.contains("access denied") || message.contains(LEGACY_ACCESS_DENIED) ->
            context.getString(R.string.github_actions_error_detail_nightly_access_denied)

        lower.contains("could not find the actions resource") ||
            lower.contains("could not find matching actions resources") ||
            message.contains(LEGACY_ACTIONS_RESOURCE_NOT_FOUND) ->
            context.getString(R.string.github_actions_error_detail_nightly_resource_missing)

        lower.contains("expired artifact") || message.contains(LEGACY_ARTIFACT_EXPIRED) ->
            context.getString(R.string.github_actions_error_detail_nightly_artifact_expired)

        lower.contains("rate limited") || message.contains(LEGACY_RATE_LIMITED) ->
            context.getString(R.string.github_actions_error_detail_nightly_rate_limited)

        message.startsWith("GitHub Actions request failed") ||
            message.startsWith(LEGACY_ACTIONS_REQUEST_FAILED_PREFIX) ->
            context.getString(R.string.github_actions_error_detail_request_failed, message)

        lower.contains("read failed") || message.contains(LEGACY_READ_FAILED) ->
            context.getString(R.string.github_actions_error_detail_nightly_read_failed, message)

        else -> message
    }
}

internal fun localizedGitHubRepositoryDiscoveryErrorMessage(
    context: Context,
    error: Throwable,
): String {
    val httpError = error as? GitHubRepositoryDiscoveryHttpException
    if (httpError != null) {
        return localizedGitHubRepositoryDiscoveryHttpErrorMessage(
            context = context,
            statusCode = httpError.statusCode,
            responseMessage = httpError.responseMessage,
        )
    }
    val message = error.message?.trim().orEmpty()
    val legacyHttpError = message.toLegacyGitHubRepositoryDiscoveryHttpError()
    if (legacyHttpError != null) {
        return localizedGitHubRepositoryDiscoveryHttpErrorMessage(
            context = context,
            statusCode = legacyHttpError.statusCode,
            responseMessage = legacyHttpError.responseMessage,
        )
    }
    return message.ifBlank { context.getString(R.string.common_unknown) }
}

private fun localizedGitHubRepositoryDiscoveryHttpErrorMessage(
    context: Context,
    statusCode: Int,
    responseMessage: String,
): String {
    val normalizedMessage = responseMessage.trim().lowercase()
    return when {
        statusCode == 401 ->
            context.getString(R.string.github_error_repo_discovery_token_invalid)

        statusCode == 403 && normalizedMessage.contains("rate limit") ->
            context.getString(R.string.github_error_repo_discovery_rate_limited)

        statusCode == 429 ->
            context.getString(R.string.github_error_repo_discovery_rate_limited)

        statusCode == 403 ->
            context.getString(R.string.github_error_repo_discovery_forbidden)

        statusCode == 422 ->
            context.getString(R.string.github_error_repo_discovery_query_rejected)

        else ->
            context.getString(R.string.github_error_repo_discovery_http_failed, statusCode)
    }
}

private fun String.toLegacyGitHubRepositoryDiscoveryHttpError(): LegacyGitHubRepositoryDiscoveryHttpError? {
    val prefix = "GitHub discovery request failed: HTTP "
    if (!startsWith(prefix)) return null
    val remainder = removePrefix(prefix).trim()
    val statusCode = remainder.substringBefore(' ').toIntOrNull() ?: return null
    val responseMessage = remainder.substringAfter(' ', missingDelimiterValue = "").trim()
    return LegacyGitHubRepositoryDiscoveryHttpError(
        statusCode = statusCode,
        responseMessage = responseMessage,
    )
}

private data class LegacyGitHubRepositoryDiscoveryHttpError(
    val statusCode: Int,
    val responseMessage: String,
)

internal fun localizedGitHubShareImportErrorMessage(
    context: Context,
    rawMessage: String?
): String {
    val message = rawMessage?.trim().orEmpty()
    if (message.isBlank()) return context.getString(R.string.common_unknown)
    return when (message) {
        "No valid GitHub link was detected",
        LEGACY_SHARE_NO_VALID_LINK ->
            context.getString(R.string.github_share_import_error_no_valid_link)

        "The target release contains no usable APK",
        LEGACY_SHARE_NO_USABLE_APK ->
            context.getString(R.string.github_share_import_error_no_usable_apk)

        "Share import resolution failed",
        LEGACY_SHARE_RESOLVE_FAILED ->
            context.getString(R.string.github_share_import_error_resolve_failed)

        "This repository has no usable release",
        LEGACY_SHARE_NO_RELEASE ->
            context.getString(R.string.github_share_import_error_no_release)

        "The shared link is missing a release tag",
        LEGACY_SHARE_MISSING_RELEASE_TAG ->
            context.getString(R.string.github_share_import_error_missing_release_tag)

        "This repository has no stable release",
        LEGACY_SHARE_NO_STABLE_RELEASE ->
            context.getString(R.string.github_share_import_error_no_stable_release)

        else -> localizedGitHubPageErrorMessage(context, message)
    }
}

internal fun localizedGitHubPageErrorMessage(
    context: Context,
    error: Throwable,
    fallbackMessage: String = context.getString(R.string.common_unknown),
): String =
    localizedGitHubPageErrorMessage(
        context = context,
        rawMessage =
            error.message
                ?.takeIf { it.isNotBlank() }
                ?: error.javaClass.simpleName,
        fallbackMessage = fallbackMessage,
    )

internal fun localizedGitHubPageErrorMessage(
    context: Context,
    rawMessage: String?,
    fallbackMessage: String = context.getString(R.string.common_unknown),
): String {
    val message = rawMessage?.trim().orEmpty()
    if (message.isBlank()) return fallbackMessage
    if (GitHubTrackedReleaseStatus.fromMessage(message) == GitHubTrackedReleaseStatus.Failed) {
        return localizedGitHubTrackedReleaseStatusMessage(context, message)
    }
    val lower = message.lowercase()
    val httpStatusCode = message.githubPageHttpStatusCodeOrNull()
    return when {
        message == "GitHub API token is invalid or expired" ->
            context.getString(R.string.github_error_github_api_token_invalid)

        message == "GitHub guest API is rate limited. Try again later or enter a token" ->
            context.getString(R.string.github_error_github_guest_rate_limited)

        message == "GitHub API is rate limited" ||
            message == "GitHub API asset download is rate limited" ||
            (lower.contains("api rate limit exceeded") && lower.contains("github")) ->
            context.getString(R.string.github_error_github_api_rate_limited)

        message == "GitHub API asset URL has expired" ->
            context.getString(R.string.github_error_github_asset_url_expired)

        message == "GitHub API asset download returned no redirect URL" ->
            context.getString(R.string.github_error_github_asset_no_redirect)

        message == "GitHub connection closed unexpectedly. Try again later." ||
            message == "GitHub page connection closed unexpectedly. Try again later." ||
            (lower.contains("github") && lower.contains("connection closed")) ->
            context.getString(R.string.github_error_github_connection_closed)

        message == "No release was found for this tag" ||
            message == "This repository has no usable release" ->
            context.getString(R.string.github_share_import_error_no_release)

        message == "This repository has no stable release" ->
            context.getString(R.string.github_share_import_error_no_stable_release)

        message == "This repository has no stable release tag" ||
            message == "missing Git release tag" ||
            message == "The shared link is missing a release tag" ->
            context.getString(R.string.github_share_import_error_missing_release_tag)

        message == "Invalid GitHub repository URL" ||
            message == "invalid Git repository URL" ->
            context.getString(R.string.github_error_invalid_repository_url)

        message == "invalid direct APK URL" ->
            context.getString(R.string.github_error_invalid_direct_apk_url)

        message == "The target release contains no usable APK" ||
            message == "The latest stable release contains no APK asset" ||
            message == "Release contains no APK asset" ||
            message == "No APK asset manifest could be parsed" ->
            context.getString(R.string.github_share_import_error_no_usable_apk)

        message.startsWith("No downloadable assets found on") ->
            context.getString(R.string.github_error_no_downloadable_assets)

        message == "Git release notes are unavailable" ->
            context.getString(R.string.github_error_release_notes_unavailable)

        message == "Git release assets are unavailable" ->
            context.getString(R.string.github_error_release_assets_unavailable)

        message == "No Git tags found" ||
            message == "No Git release or tag entries found" ->
            context.getString(R.string.github_error_no_git_release_tags)

        message == "Git repository package scanning is unavailable" ->
            context.getString(R.string.github_error_git_package_scan_unavailable)

        message == "remote APK manifest read failed" ||
            lower.contains("no apk manifest could be inspected") ->
            context.getString(R.string.github_error_remote_apk_manifest_failed)

        lower.startsWith("direct apk") && lower.contains("too large") ->
            context.getString(R.string.github_error_direct_apk_index_too_large)

        httpStatusCode != null && lower.startsWith("github api asset download") ->
            context.getString(R.string.github_error_github_asset_http_failed, httpStatusCode)

        httpStatusCode != null && lower.startsWith("github") ->
            context.getString(R.string.github_error_github_http_failed, httpStatusCode)

        httpStatusCode != null && lower.startsWith("git repository") ->
            context.getString(R.string.github_error_git_repository_http_failed, httpStatusCode)

        httpStatusCode != null && lower.startsWith("git release") ->
            context.getString(R.string.github_error_git_asset_http_failed, httpStatusCode)

        httpStatusCode != null && lower.startsWith("direct apk") ->
            context.getString(R.string.github_error_direct_apk_http_failed, httpStatusCode)

        httpStatusCode != null && lower.startsWith("http") ->
            context.getString(R.string.github_error_download_http_failed, httpStatusCode)

        else -> {
            val actionsMessage = localizedGitHubActionsErrorMessage(context, message)
            if (actionsMessage != message) actionsMessage else message
        }
    }
}

internal fun localizedGitHubTrackedReleaseStatusMessage(
    context: Context,
    rawMessage: String,
): String {
    val message = rawMessage.trim()
    if (GitHubTrackedReleaseStatus.fromMessage(message) != GitHubTrackedReleaseStatus.Failed) {
        return message
    }
    val prefix = context.getString(R.string.github_check_failed_prefix)
    val detail = message.githubTrackedReleaseFailureDetail()
    if (detail.isBlank()) return prefix
    val localizedDetail =
        localizedGitHubPageErrorMessage(
            context = context,
            rawMessage = detail,
            fallbackMessage = detail,
        )
    return context.getString(R.string.github_error_check_failed_detail, localizedDetail)
}

private const val LEGACY_ACTIONS_DOWNLOAD_TOKEN_REQUIRED =
    "\u4e0b\u8f7d GitHub Actions artifact \u9700\u8981\u586b\u5199 token"
private const val LEGACY_ACTIONS_API_TOKEN_REQUIRED =
    "GitHub Actions API Token \u9700\u8981\u586b\u5199 token"
private const val LEGACY_ARTIFACT_MISSING_DOWNLOAD =
    "artifact \u7f3a\u5c11\u4e0b\u8f7d\u5730\u5740\uff0c\u4e14\u672a\u63d0\u4f9b\u4ed3\u5e93\u4fe1\u606f"
private const val LEGACY_ARTIFACT_NO_REDIRECT =
    "GitHub Actions artifact \u4e0b\u8f7d\u672a\u8fd4\u56de\u8df3\u8f6c\u5730\u5740"
private const val LEGACY_WORKFLOW_NOT_FOUND_PREFIX =
    "GitHub \u516c\u5f00 API \u6ca1\u6709\u627e\u5230\u5339\u914d workflow\uff1a"
private const val LEGACY_ACTIONS_TOKEN_INVALID =
    "GitHub Actions token \u65e0\u6548\u6216\u5df2\u8fc7\u671f"
private const val LEGACY_ACTIONS_GUEST_RATE_LIMITED_PREFIX =
    "GitHub Actions \u6e38\u5ba2 API \u5df2\u9650\u6d41"
private const val LEGACY_ACTIONS_API_RATE_LIMITED =
    "GitHub Actions API \u5df2\u9650\u6d41"
private const val LEGACY_ACTIONS_API_FORBIDDEN_PREFIX =
    "GitHub Actions API \u88ab\u62d2\u7edd\u8bbf\u95ee"
private const val LEGACY_ACTIONS_RESOURCE_MISSING =
    "\u4ed3\u5e93\u6216 GitHub Actions \u8d44\u6e90\u4e0d\u5b58\u5728\uff0c\u6216\u5f53\u524d token \u65e0\u6743\u8bbf\u95ee"
private const val LEGACY_ACTIONS_ARTIFACT_EXPIRED =
    "GitHub Actions artifact \u5df2\u8fc7\u671f"
private const val LEGACY_NIGHTLY_RAW_ARTIFACT_PREFIX =
    "nightly.link \u5f53\u524d\u65e0\u6cd5\u76f4\u63a5\u4e0b\u8f7d\u539f\u59cb APK artifact"
private const val LEGACY_NIGHTLY_NO_WORKFLOW_ARTIFACT =
    "nightly.link \u6ca1\u6709\u8bfb\u53d6\u5230 workflow artifact"
private const val LEGACY_NIGHTLY_NO_DOWNLOADABLE_ARTIFACTS_PREFIX =
    "nightly.link \u6ca1\u6709\u8bfb\u53d6\u5230"
private const val LEGACY_ACCESS_DENIED = "\u8bbf\u95ee\u88ab\u62d2\u7edd"
private const val LEGACY_ACTIONS_RESOURCE_NOT_FOUND = "\u6ca1\u6709\u627e\u5230\u5bf9\u5e94 Actions \u8d44\u6e90"
private const val LEGACY_ARTIFACT_EXPIRED = "artifact \u5df2\u8fc7\u671f"
private const val LEGACY_RATE_LIMITED = "\u9650\u6d41"
private const val LEGACY_ACTIONS_REQUEST_FAILED_PREFIX = "GitHub Actions \u8bf7\u6c42\u5931\u8d25"
private const val LEGACY_READ_FAILED = "\u8bfb\u53d6\u5931\u8d25"
private const val LEGACY_SHARE_NO_VALID_LINK =
    "\u672a\u8bc6\u522b\u5230\u6709\u6548\u7684 GitHub \u94fe\u63a5"
private const val LEGACY_SHARE_NO_USABLE_APK =
    "\u76ee\u6807 release \u4e2d\u672a\u627e\u5230\u53ef\u7528 APK"
private const val LEGACY_SHARE_RESOLVE_FAILED =
    "\u5206\u4eab\u5bfc\u5165\u89e3\u6790\u5931\u8d25"
private const val LEGACY_SHARE_NO_RELEASE =
    "\u8be5\u4ed3\u5e93\u6682\u65e0\u53ef\u7528 release"
private const val LEGACY_SHARE_MISSING_RELEASE_TAG =
    "\u5206\u4eab\u94fe\u63a5\u7f3a\u5c11 release tag"
private const val LEGACY_SHARE_NO_STABLE_RELEASE =
    "\u8be5\u4ed3\u5e93\u6682\u65e0\u7a33\u5b9a\u7248 release"

private fun String.githubPageHttpStatusCodeOrNull(): Int? =
    githubPageHttpStatusRegex
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?.toIntOrNull()

private fun String.githubTrackedReleaseFailureDetail(): String {
    val message = trim()
    val failed = GitHubTrackedReleaseStatus.Failed
    val prefixes =
        listOf(
            "${failed.defaultMessage}:",
            "${failed.defaultMessage}\uff1a",
            "${failed.defaultMessage} -",
            "\u68c0\u67e5\u5931\u8d25:",
            "\u68c0\u67e5\u5931\u8d25\uff1a",
            "Check failed:",
        )
    prefixes.forEach { prefix ->
        if (message.startsWith(prefix)) return message.removePrefix(prefix).trim()
    }
    return ""
}
