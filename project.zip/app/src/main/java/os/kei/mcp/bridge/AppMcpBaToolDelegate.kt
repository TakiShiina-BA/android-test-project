package os.kei.mcp.bridge

import os.kei.feature.ba.mcp.McpBaToolDelegate
import os.kei.feature.github.domain.GitHubCacheService
import os.kei.mcp.server.McpToolEnvironment
import os.kei.ui.page.main.ba.support.BASettingsStore
import os.kei.ui.page.main.ba.support.BA_CRAFT_SLOT_COUNT
import os.kei.ui.page.main.ba.support.BaAccountId
import os.kei.ui.page.main.ba.support.BaCraftFunction
import os.kei.ui.page.main.ba.support.BaDailyDoneOutcome
import os.kei.ui.page.main.ba.support.BaPageSnapshot
import os.kei.ui.page.main.ba.support.baCalendarKindLabel
import os.kei.ui.page.main.ba.support.baPoolTagLabel
import os.kei.ui.page.main.ba.support.cafeDailyCapacity
import os.kei.ui.page.main.ba.support.cafeHourlyGain
import os.kei.ui.page.main.ba.support.cafeStorageCap
import os.kei.ui.page.main.ba.support.calculateApFullAtMs
import os.kei.ui.page.main.ba.support.calculateApNextPointAtMs
import os.kei.ui.page.main.ba.support.calculateInviteTicketAvailableMs
import os.kei.ui.page.main.ba.support.calculateNextHeadpatAvailableMs
import os.kei.ui.page.main.ba.support.decodeBaCalendarEntries
import os.kei.ui.page.main.ba.support.decodeBaPoolEntries
import os.kei.ui.page.main.ba.support.displayAp
import os.kei.ui.page.main.ba.support.fractionalApPart
import os.kei.ui.page.main.ba.support.gameKeeServerId
import os.kei.ui.page.main.ba.support.slotOf
import os.kei.ui.page.main.ba.support.summary
import os.kei.ui.page.main.student.BaGuideBgmFavoriteRepository
import os.kei.ui.page.main.student.BaStudentGuideStore
import os.kei.ui.page.main.student.catalog.BaGuideCatalogStore
import os.kei.ui.page.main.student.catalog.BaGuideCatalogTab
import os.kei.ui.page.main.student.catalog.clearBaGuideCatalogCache
import os.kei.ui.page.main.student.catalog.isBaGuideCatalogBundleComplete
import os.kei.ui.page.main.student.catalog.isBaGuideCatalogCacheExpired
import os.kei.ui.page.main.student.catalog.loadCachedBaGuideCatalogBundle
import os.kei.ui.page.main.student.fetch.normalizeGuideUrl
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.roundToInt

internal class AppMcpBaToolDelegate(
    private val environment: McpToolEnvironment
) : McpBaToolDelegate {
    private val appContext get() = environment.appContext
    private val bgmFavoriteRepository = BaGuideBgmFavoriteRepository()
    private fun resolveServerIndex(requestedServerIndex: Int?): Int {
        return requestedServerIndex?.coerceIn(0, 2) ?: BASettingsStore.loadSnapshot().serverIndex
    }

    override fun defaultGuideRefreshIntervalHours(): Int {
        return BASettingsStore.loadCalendarRefreshIntervalHours()
    }

    /**
     * Resolves a snapshot for [accountId], falling back to the active account when it is blank.
     *
     * An id that matches nothing also falls back rather than erroring: an assistant working from a stale
     * account list should get a usable answer plus the `accountId` echo showing which account it is
     * really describing, not a failed call.
     */
    private fun snapshotForAccount(accountId: String): Pair<BaPageSnapshot, BaAccountId?> {
        val trimmed = accountId.trim()
        if (trimmed.isEmpty()) return BASettingsStore.loadSnapshot() to null
        val requested = BaAccountId(trimmed)
        val snapshot =
            BASettingsStore.loadSnapshotForAccount(requested)
                ?: return BASettingsStore.loadSnapshot() to null
        return snapshot to requested
    }

    override fun buildBaAccountsText(): String {
        val nowMs = System.currentTimeMillis()
        val accountState = BASettingsStore.loadAccountState()
        val tileState = BASettingsStore.loadDailyTileState()
        return buildString {
            appendLine("accountCount=${accountState.accounts.size}")
            appendLine("enabledCount=${accountState.accounts.count { it.profile.enabled }}")
            appendLine("activeAccountId=${accountState.activeAccountId?.value.orEmpty()}")
            appendLine(
                "allAccountsFollowGlobalNotificationSettings=" +
                    "${accountState.allAccountsFollowGlobalNotificationSettings}",
            )
            appendLine("dailyTileMode=${tileState.mode.name}")
            accountState.accounts.forEachIndexed { index, account ->
                val snapshot =
                    BASettingsStore.loadSnapshotForAccount(account.profile.id) ?: return@forEachIndexed
                appendLine(
                    mcpBaAccountLine(
                        profile = account.profile,
                        snapshot = snapshot,
                        active = accountState.activeAccountId == account.profile.id,
                        tileSlot = tileState.slotOf(account.profile.id),
                        index = index,
                        nowMs = nowMs,
                    ),
                )
            }
        }.trim()
    }

    /**
     * Previews or applies the dailies template.
     *
     * Both modes go through the store, which runs one shared implementation — a preview assembled here
     * could promise an outcome the write would not produce. Disabled accounts are skipped either way,
     * matching the tile.
     */
    override fun buildBaDailyDoneText(accountId: String, apply: Boolean): String {
        val nowMs = System.currentTimeMillis()
        val trimmed = accountId.trim()
        // A blank id means "every enabled account", which the store expresses as a null filter. An id
        // that matches nothing must not collapse into that, so it stays an explicit empty list.
        val filter = if (trimmed.isEmpty()) null else listOf(BaAccountId(trimmed))
        val targets = BASettingsStore.dailyDoneTargets(accountIds = filter)
        val outcomes =
            if (apply) {
                BASettingsStore.applyDailyDone(accountIds = filter, nowMs = nowMs)
            } else {
                BASettingsStore.previewDailyDone(accountIds = filter, nowMs = nowMs)
            }
        return buildString {
            appendLine("applied=$apply")
            appendLine("requestedAccountId=$trimmed")
            appendLine("targetCount=${targets.size}")
            appendLine("changedCount=${outcomes.count { it.value.changedAnything }}")
            appendLine("craftSlotsStarted=${outcomes.values.sumOf { it.craftSlotsStarted }}")
            if (targets.isEmpty()) {
                // Distinguish "nothing to do" from "the id was wrong", which the counts alone cannot.
                appendLine(
                    if (trimmed.isEmpty()) {
                        "note=no enabled account"
                    } else {
                        "note=no enabled account matches the requested id"
                    },
                )
            }
            if (!apply) appendLine("note=preview only, pass apply=true to write")
            targets.forEach { account ->
                val outcome = outcomes[account.profile.id] ?: BaDailyDoneOutcome()
                appendLine(
                    mcpBaDailyDoneLine(
                        accountName = account.profile.displayName,
                        accountId = account.profile.id.value,
                        outcome = outcome,
                        applied = apply,
                    ),
                )
            }
        }.trim()
    }

    override fun buildBaSnapshotText(accountId: String): String {
        val nowMs = System.currentTimeMillis()
        val (snapshot, resolvedAccountId) = snapshotForAccount(accountId)
        val serverIndex = snapshot.serverIndex.coerceIn(0, 2)
        val displayedAp = displayAp(snapshot.apCurrent)
        val apFraction = fractionalApPart(snapshot.apCurrent)
        val apPercent = if (snapshot.apLimit <= 0) {
            0.0
        } else {
            (snapshot.apCurrent / snapshot.apLimit.toDouble() * 100.0).coerceIn(0.0, 999.0)
        }
        val apFullAtMs = calculateApFullAtMs(
            apLimit = snapshot.apLimit,
            apCurrent = snapshot.apCurrent,
            apRegenBaseMs = snapshot.apRegenBaseMs,
            nowMs = nowMs
        )
        val apNextPointAtMs = calculateApNextPointAtMs(
            apLimit = snapshot.apLimit,
            apCurrent = snapshot.apCurrent,
            apRegenBaseMs = snapshot.apRegenBaseMs,
            nowMs = nowMs
        )
        val headpatReadyAtMs = calculateNextHeadpatAvailableMs(
            lastHeadpatMs = snapshot.coffeeHeadpatMs,
            serverIndex = serverIndex
        )
        val invite1ReadyAtMs = calculateInviteTicketAvailableMs(snapshot.coffeeInvite1UsedMs)
        val invite2ReadyAtMs = calculateInviteTicketAvailableMs(snapshot.coffeeInvite2UsedMs)
        val cafeLevel = snapshot.cafeLevel.coerceIn(1, 10)
        val cafeCap = cafeStorageCap(cafeLevel)
        val cafeStored = snapshot.cafeStoredAp.coerceIn(0.0, cafeCap)
        val cafePercent = if (cafeCap <= 0.0) 0.0 else (cafeStored / cafeCap * 100.0).coerceIn(0.0, 100.0)
        // The same derivation the collapsed Craft Chamber header uses, so the two can never disagree.
        val craftSummary = snapshot.craft.summary(nowMs)

        return buildString {
            // Echoed so a caller can tell an explicit target from the active-account fallback, which is
            // also what a stale or wrong id lands on.
            appendLine("accountId=${resolvedAccountId?.value.orEmpty()}")
            appendLine("serverIndex=$serverIndex")
            appendLine("gameKeeServerId=${gameKeeServerId(serverIndex)}")
            appendLine("calendarRefreshIntervalHours=${snapshot.calendarRefreshIntervalHours}")
            appendLine("apCurrent=$displayedAp")
            appendLine("apCurrentExact=${snapshot.apCurrent}")
            appendLine("apFraction=${(apFraction * 1000.0).roundToInt() / 1000.0}")
            appendLine("apLimit=${snapshot.apLimit}")
            appendLine("apPercent=${(apPercent * 10.0).roundToInt() / 10.0}")
            appendLine("apRegenBaseMs=${snapshot.apRegenBaseMs}")
            appendLine("apSyncMs=${snapshot.apSyncMs}")
            appendLine("apNextPointAtMs=$apNextPointAtMs")
            appendLine("apFullAtMs=$apFullAtMs")
            appendLine("apNotifyEnabled=${snapshot.apNotifyEnabled}")
            appendLine("apNotifyThreshold=${snapshot.apNotifyThreshold}")
            appendLine("apLastNotifiedLevel=${snapshot.apLastNotifiedLevel}")
            appendLine("cafeLevel=$cafeLevel")
            appendLine("cafeHourlyGain=${(cafeHourlyGain(cafeLevel) * 100.0).roundToInt() / 100.0}")
            appendLine("cafeDailyCapacity=${cafeDailyCapacity(cafeLevel)}")
            appendLine("cafeStorageCap=$cafeCap")
            appendLine("cafeStoredAp=${(cafeStored * 100.0).roundToInt() / 100.0}")
            appendLine("cafeStoredPercent=${(cafePercent * 10.0).roundToInt() / 10.0}")
            appendLine("coffeeHeadpatLastMs=${snapshot.coffeeHeadpatMs}")
            appendLine("coffeeHeadpatReadyAtMs=$headpatReadyAtMs")
            appendLine("coffeeInvite1LastMs=${snapshot.coffeeInvite1UsedMs}")
            appendLine("coffeeInvite1ReadyAtMs=$invite1ReadyAtMs")
            appendLine("coffeeInvite2LastMs=${snapshot.coffeeInvite2UsedMs}")
            appendLine("coffeeInvite2ReadyAtMs=$invite2ReadyAtMs")
            appendLine("craftNotifyEnabled=${snapshot.craftNotifyEnabled}")
            appendLine("craftRunningCount=${craftSummary.runningCount}")
            appendLine("craftReadyCount=${craftSummary.readyCount}")
            appendLine("craftNextCompletionAtMs=${craftSummary.nextCompletionAtMs ?: 0L}")
            BaCraftFunction.entries.forEach { function ->
                repeat(BA_CRAFT_SLOT_COUNT) { index ->
                    appendLine(mcpBaCraftSlotLine(snapshot.craft, function, index, nowMs))
                }
            }
            appendLine("showEndedPools=${snapshot.showEndedPools}")
            appendLine("showEndedActivities=${snapshot.showEndedActivities}")
            appendLine("showCalendarPoolImages=${snapshot.showCalendarPoolImages}")
            appendLine("craftCardExpanded=${snapshot.craftCardExpanded}")
            appendLine("idNickname=${snapshot.idNickname}")
            appendLine("idFriendCode=${snapshot.idFriendCode}")
        }.trim()
    }

    override fun buildBaCalendarCacheText(
        requestedServerIndex: Int?,
        includeEntries: Boolean,
        limit: Int
    ): String {
        val nowMs = System.currentTimeMillis()
        val refreshHours = BASettingsStore.loadCalendarRefreshIntervalHours()
        val refreshIntervalMs = refreshHours.coerceAtLeast(1) * 60L * 60L * 1000L
        val serverIndex = resolveServerIndex(requestedServerIndex)
        val snapshot = BASettingsStore.loadCalendarCacheSnapshot(serverIndex)
        val entries = runCatching { decodeBaCalendarEntries(snapshot.raw, nowMs) }.getOrElse { emptyList() }
        val expired = snapshot.syncMs <= 0L || (nowMs - snapshot.syncMs).coerceAtLeast(0L) >= refreshIntervalMs

        return buildString {
            appendLine("serverIndex=$serverIndex")
            appendLine("gameKeeServerId=${gameKeeServerId(serverIndex)}")
            appendLine("refreshIntervalHours=$refreshHours")
            appendLine("cacheVersion=${snapshot.version}")
            appendLine("cachePresent=${snapshot.raw.isNotBlank()}")
            appendLine("cacheRawChars=${snapshot.raw.length}")
            appendLine("cacheSyncMs=${snapshot.syncMs}")
            appendLine("cacheExpired=$expired")
            appendLine("entryCount=${entries.size}")
            if (includeEntries && entries.isNotEmpty()) {
                entries.take(limit).forEachIndexed { index, entry ->
                    val kindLabel = appContext.baCalendarKindLabel(entry.kindId, entry.kindName)
                    appendLine(
                        "entry[$index]=id:${entry.id} | kind:$kindLabel | running:${entry.isRunning} | title:${entry.title} | beginAtMs:${entry.beginAtMs} | endAtMs:${entry.endAtMs} | link:${entry.linkUrl}"
                    )
                }
            }
        }.trim()
    }

    override fun buildBaPoolCacheText(
        requestedServerIndex: Int?,
        includeEntries: Boolean,
        limit: Int
    ): String {
        val nowMs = System.currentTimeMillis()
        val refreshHours = BASettingsStore.loadCalendarRefreshIntervalHours()
        val refreshIntervalMs = refreshHours.coerceAtLeast(1) * 60L * 60L * 1000L
        val serverIndex = resolveServerIndex(requestedServerIndex)
        val snapshot = BASettingsStore.loadPoolCacheSnapshot(serverIndex)
        val entries = runCatching { decodeBaPoolEntries(snapshot.raw, nowMs) }.getOrElse { emptyList() }
        val expired = snapshot.syncMs <= 0L || (nowMs - snapshot.syncMs).coerceAtLeast(0L) >= refreshIntervalMs

        return buildString {
            appendLine("serverIndex=$serverIndex")
            appendLine("gameKeeServerId=${gameKeeServerId(serverIndex)}")
            appendLine("refreshIntervalHours=$refreshHours")
            appendLine("cacheVersion=${snapshot.version}")
            appendLine("cachePresent=${snapshot.raw.isNotBlank()}")
            appendLine("cacheRawChars=${snapshot.raw.length}")
            appendLine("cacheSyncMs=${snapshot.syncMs}")
            appendLine("cacheExpired=$expired")
            appendLine("entryCount=${entries.size}")
            if (includeEntries && entries.isNotEmpty()) {
                entries.take(limit).forEachIndexed { index, entry ->
                    val tagLabel = appContext.baPoolTagLabel(entry.tagId, entry.tagName)
                    appendLine(
                        "entry[$index]=id:${entry.id} | tag:$tagLabel | running:${entry.isRunning} | name:${entry.name} | startAtMs:${entry.startAtMs} | endAtMs:${entry.endAtMs} | link:${entry.linkUrl}"
                    )
                }
            }
        }.trim()
    }

    private fun parseCatalogTab(raw: String): BaGuideCatalogTab? {
        return when (raw.trim().lowercase(Locale.ROOT)) {
            "", "all" -> null
            "student", "students", "实装学生" -> BaGuideCatalogTab.Student
            "npc", "npcs", "npc_satellite", "npc-satellite", "npc及卫星" -> BaGuideCatalogTab.NpcSatellite
            else -> null
        }
    }

    override fun buildGuideCatalogCacheText(
        tab: String,
        includeEntries: Boolean,
        limit: Int
    ): String {
        val filterTab = parseCatalogTab(tab)
        val bundle = loadCachedBaGuideCatalogBundle()
        val counts = BaGuideCatalogStore.cachedEntryCounts()
        val refreshHours = BaGuideCatalogStore.loadIncrementalRefreshIntervalHours()
        val complete = isBaGuideCatalogBundleComplete(bundle)
        val expired = isBaGuideCatalogCacheExpired(bundle, refreshHours)
        val latestSyncedAtMs = bundle?.syncedAtMs ?: BaGuideCatalogStore.latestSyncedAtMs()

        val selectedEntries = buildList {
            if (bundle != null) {
                if (filterTab == null) {
                    BaGuideCatalogTab.entries.forEach { currentTab ->
                        addAll(bundle.entries(currentTab))
                    }
                } else {
                    addAll(bundle.entries(filterTab))
                }
            }
        }

        return buildString {
            appendLine("bundlePresent=${bundle != null}")
            appendLine("bundleComplete=$complete")
            appendLine("bundleExpired=$expired")
            appendLine("refreshIntervalHours=$refreshHours")
            appendLine("latestSyncedAtMs=$latestSyncedAtMs")
            appendLine("totalCachedEntryCount=${BaGuideCatalogStore.cachedEntryCount()}")
            appendLine("studentCount=${counts[BaGuideCatalogTab.Student] ?: 0}")
            appendLine("npcSatelliteCount=${counts[BaGuideCatalogTab.NpcSatellite] ?: 0}")
            appendLine("actualDataBytes=${BaGuideCatalogStore.actualDataBytes()}")
            appendLine("cacheBytesEstimated=${BaGuideCatalogStore.cacheBytesEstimated()}")
            appendLine("configBytesEstimated=${BaGuideCatalogStore.configBytesEstimated()}")
            appendLine("selectedTab=${filterTab?.name ?: "ALL"}")
            appendLine("selectedEntryCount=${selectedEntries.size}")
            if (includeEntries && selectedEntries.isNotEmpty()) {
                selectedEntries.take(limit).forEachIndexed { index, entry ->
                    appendLine(
                        "entry[$index]=tab:${entry.tab.name} | contentId:${entry.contentId} | name:${entry.name} | alias:${entry.aliasDisplay} | createdAtSec:${entry.createdAtSec} | detailUrl:${entry.detailUrl}"
                    )
                }
            }
        }.trim()
    }

    override fun buildGuideCacheOverviewText(): String {
        val payloadStats = BaStudentGuideStore.payloadStorageStats(appContext)
        return buildString {
            appendLine("currentUrl=${BaStudentGuideStore.loadCurrentUrl()}")
            appendLine("cachedEntryCount=${BaStudentGuideStore.cachedEntryCount()}")
            appendLine("latestSyncedAtMs=${BaStudentGuideStore.latestSyncedAtMs()}")
            appendLine("storageFootprintBytes=${BaStudentGuideStore.storageFootprintBytes()}")
            appendLine("actualDataBytes=${BaStudentGuideStore.actualDataBytes()}")
            appendLine("cacheBytesEstimated=${BaStudentGuideStore.cacheBytesEstimated()}")
            appendLine("configBytesEstimated=${BaStudentGuideStore.configBytesEstimated()}")
            appendLine("payloadMmkvEntryCount=${payloadStats.mmkvEntryCount}")
            appendLine("payloadFileEntryCount=${payloadStats.fileEntryCount}")
            appendLine("payloadMmkvBytes=${payloadStats.mmkvPayloadBytes}")
            appendLine("payloadFileBytes=${payloadStats.filePayloadBytes}")
            appendLine("payloadFileEnabled=${payloadStats.filePayloadEnabled}")
        }.trim()
    }

    private fun extractGuideContentId(url: String): Long {
        val text = url.trim()
        if (text.isBlank()) return 0L
        val patterns = listOf(
            Regex("/v1/content/detail/(\\d+)"),
            Regex("/tj/(\\d+)\\.html"),
            Regex("/(\\d+)\\.html")
        )
        patterns.forEach { regex ->
            val hit = regex.find(text)?.groupValues?.getOrNull(1)?.toLongOrNull()
            if (hit != null && hit > 0L) return hit
        }
        return 0L
    }

    override fun buildGuideCacheInspectText(
        url: String,
        includeSections: Boolean,
        refreshIntervalHours: Int
    ): String {
        val target = normalizeGuideUrl(url).ifBlank { BaStudentGuideStore.loadCurrentUrl() }
        if (target.isBlank()) {
            return "hasTarget=false\nmessage=No target URL. Pass url argument or open a student guide page first."
        }
        val snapshot = BaStudentGuideStore.loadInfoSnapshot(target)
        val expired = BaStudentGuideStore.isCacheExpired(
            snapshot = snapshot,
            refreshIntervalHours = refreshIntervalHours
        )
        val info = snapshot.info

        return buildString {
            appendLine("hasTarget=true")
            appendLine("targetUrl=$target")
            appendLine("contentId=${extractGuideContentId(target)}")
            appendLine("hasCache=${snapshot.hasCache}")
            appendLine("isComplete=${snapshot.isComplete}")
            appendLine("isExpired=$expired")
            appendLine("refreshIntervalHours=$refreshIntervalHours")
            appendLine("syncedAtMs=${snapshot.syncedAtMs}")
            appendLine("infoPresent=${info != null}")
            if (info != null) {
                appendLine("title=${info.title}")
                appendLine("subtitle=${info.subtitle}")
                appendLine("summary=${info.summary}")
                appendLine("statsCount=${info.stats.size}")
                appendLine("skillRowsCount=${info.skillRows.size}")
                appendLine("profileRowsCount=${info.profileRows.size}")
                appendLine("galleryItemsCount=${info.galleryItems.size}")
                appendLine("growthRowsCount=${info.growthRows.size}")
                appendLine("simulateRowsCount=${info.simulateRows.size}")
                appendLine("voiceRowsCount=${info.voiceRows.size}")
                appendLine("voiceEntriesCount=${info.voiceEntries.size}")
                appendLine("voiceHeadersCount=${info.voiceLanguageHeaders.size}")
                appendLine("voiceCvLangCount=${info.voiceCvByLanguage.size}")
                if (includeSections) {
                    appendLine("voiceCvByLanguage=${info.voiceCvByLanguage.entries.joinToString(" | ") { "${it.key}:${it.value}" }}")
                    appendLine("tabSkillIconUrl=${info.tabSkillIconUrl}")
                    appendLine("tabProfileIconUrl=${info.tabProfileIconUrl}")
                    appendLine("tabVoiceIconUrl=${info.tabVoiceIconUrl}")
                    appendLine("tabGalleryIconUrl=${info.tabGalleryIconUrl}")
                    appendLine("tabSimulateIconUrl=${info.tabSimulateIconUrl}")
                }
            }
        }.trim()
    }

    override fun buildGuideMediaListText(
        url: String,
        kind: String,
        limit: Int
    ): String {
        val target = normalizeGuideUrl(url).ifBlank { BaStudentGuideStore.loadCurrentUrl() }
        if (target.isBlank()) {
            return "hasTarget=false\nmessage=No target URL. Pass url argument or open a student guide page first."
        }
        val snapshot = BaStudentGuideStore.loadInfoSnapshot(target)
        val info = snapshot.info ?: return buildString {
            appendLine("hasTarget=true")
            appendLine("targetUrl=$target")
            appendLine("hasCache=${snapshot.hasCache}")
            appendLine("infoPresent=false")
        }.trim()

        val normalizedKind = normalizeGuideMediaKind(kind)
        val galleryRows = info.galleryItems.filter { item ->
            when (normalizedKind) {
                "gallery", "all" -> true
                "image" -> item.mediaType.equals("image", ignoreCase = true)
                "video" -> item.mediaType.equals("video", ignoreCase = true)
                else -> false
            }
        }
        val voiceRows = info.voiceEntries.filter { entry ->
            normalizedKind == "all" || normalizedKind == "voice" || normalizedKind == "audio"
        }

        var emitted = 0
        return buildString {
            appendLine("hasTarget=true")
            appendLine("targetUrl=$target")
            appendLine("title=${info.title}")
            appendLine("galleryCount=${info.galleryItems.size}")
            appendLine("voiceEntryCount=${info.voiceEntries.size}")
            appendLine("kind=$normalizedKind")
            appendLine("limit=$limit")
            galleryRows.forEachIndexed { index, item ->
                if (emitted >= limit) return@forEachIndexed
                appendLine(
                    "gallery[$index]=title:${item.title} | type:${item.mediaType} | image:${item.imageUrl} | media:${item.mediaUrl} | unlock:${item.memoryUnlockLevel} | note:${item.note}"
                )
                emitted += 1
            }
            voiceRows.forEachIndexed { index, entry ->
                if (emitted >= limit) return@forEachIndexed
                val audioUrls = (entry.audioUrls + entry.audioUrl).map { it.trim() }.filter { it.isNotBlank() }.distinct()
                appendLine(
                    "voice[$index]=section:${entry.section} | title:${entry.title} | audioCount:${audioUrls.size} | audio:${audioUrls.firstOrNull().orEmpty()}"
                )
                emitted += 1
            }
            appendLine("returned=$emitted")
        }.trim()
    }

    private fun normalizeGuideMediaKind(kind: String): String {
        return when (kind.trim().lowercase(Locale.ROOT)) {
            "gallery", "image", "video", "voice", "audio" -> kind.trim().lowercase(Locale.ROOT)
            else -> "all"
        }
    }

    override suspend fun buildGuideBgmFavoritesText(
        action: String,
        query: String,
        limit: Int,
        rawJson: String,
        apply: Boolean
    ): String {
        return when (action.trim().lowercase(Locale.ROOT)) {
            "export" -> bgmFavoriteRepository.buildExportJson()
            "import" -> buildGuideBgmFavoritesImportText(rawJson = rawJson, apply = apply)
            else -> buildGuideBgmFavoritesListText(query = query, limit = limit)
        }
    }

    private fun buildGuideBgmFavoritesListText(query: String, limit: Int): String {
        val favorites = bgmFavoriteRepository.favoritesSnapshot()
        val key = query.trim().lowercase(Locale.ROOT)
        val filtered = if (key.isBlank()) {
            favorites
        } else {
            favorites.filter { favorite ->
                favorite.audioUrl.lowercase(Locale.ROOT).contains(key) ||
                    favorite.title.lowercase(Locale.ROOT).contains(key) ||
                    favorite.studentTitle.lowercase(Locale.ROOT).contains(key) ||
                    favorite.sourceUrl.lowercase(Locale.ROOT).contains(key) ||
                    favorite.note.lowercase(Locale.ROOT).contains(key)
            }
        }
        val rows = filtered.take(limit)
        return buildString {
            appendLine("total=${favorites.size}")
            appendLine("matched=${filtered.size}")
            appendLine("returned=${rows.size}")
            appendLine("query=${query.ifBlank { "(none)" }}")
            rows.forEachIndexed { index, favorite ->
                appendLine(
                    "favorite[$index]=title:${favorite.title} | student:${favorite.studentTitle} | audio:${favorite.audioUrl} | source:${favorite.sourceUrl} | favoritedAtMs:${favorite.favoritedAtMs}"
                )
            }
        }.trim()
    }

    private suspend fun buildGuideBgmFavoritesImportText(rawJson: String, apply: Boolean): String {
        val importedUrls = parseBgmFavoriteAudioUrls(rawJson)
        val existingUrls = bgmFavoriteRepository.favoritesSnapshot().map { it.audioUrl }.toSet()
        val addedCount = importedUrls.count { it !in existingUrls }
        val updatedCount = importedUrls.count { it in existingUrls }
        val result = if (apply) bgmFavoriteRepository.importMerged(rawJson) else null
        return buildString {
            appendLine("apply=$apply")
            appendLine("importedCount=${result?.importedCount ?: importedUrls.size}")
            appendLine("newCount=${result?.addedCount ?: addedCount}")
            appendLine("updatedCount=${result?.updatedCount ?: updatedCount}")
            appendLine("applied=${result != null}")
        }.trim()
    }

    private fun parseBgmFavoriteAudioUrls(rawJson: String): List<String> {
        val trimmed = rawJson.trim()
        if (trimmed.isBlank()) return emptyList()
        return runCatching {
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val root = JSONObject(trimmed)
                root.optJSONArray("favorites")
                    ?: root.optJSONArray("bgmFavorites")
                    ?: JSONArray()
            }
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val audioUrl = item.optString("audioUrl").trim()
                    if (audioUrl.isNotBlank()) add(audioUrl)
                }
            }.distinct()
        }.getOrDefault(emptyList())
    }

    private fun normalizeCacheClearScope(raw: String): String {
        return when (raw.trim().lowercase(Locale.ROOT)) {
            "ba_calendar_pool", "calendar_pool", "ba-calendar-pool" -> "ba_calendar_pool"
            "ba_guide_catalog", "guide_catalog", "ba-guide-catalog" -> "ba_guide_catalog"
            "ba_guide_all", "guide_all", "ba-guide-all" -> "ba_guide_all"
            "ba_guide_url", "guide_url", "ba-guide-url" -> "ba_guide_url"
            "github_check", "github", "github_cache", "github-check" -> "github_check"
            else -> "all"
        }
    }

    override fun buildCacheClearText(scope: String, url: String): String {
        val normalizedScope = normalizeCacheClearScope(scope)
        val cleared = mutableListOf<String>()
        var message = "ok"

        when (normalizedScope) {
            "ba_calendar_pool" -> {
                BASettingsStore.clearCalendarAndPoolCaches()
                cleared += "ba_calendar_pool"
            }

            "ba_guide_catalog" -> {
                clearBaGuideCatalogCache(appContext)
                cleared += "ba_guide_catalog"
            }

            "ba_guide_all" -> {
                BaStudentGuideStore.clearAllCachedInfo()
                cleared += "ba_guide_all"
            }

            "ba_guide_url" -> {
                val target = normalizeGuideUrl(url)
                if (target.isBlank()) {
                    message = "url_required_for_ba_guide_url"
                } else {
                    BaStudentGuideStore.clearCachedInfo(target)
                    cleared += "ba_guide_url:$target"
                }
            }

            "github_check" -> {
                GitHubCacheService.clearGitHubCheckCaches()
                cleared += "github_check"
            }

            else -> {
                BASettingsStore.clearCalendarAndPoolCaches()
                BaStudentGuideStore.clearAllCachedInfo()
                clearBaGuideCatalogCache(appContext)
                GitHubCacheService.clearGitHubCheckCaches()
                cleared += "ba_calendar_pool"
                cleared += "ba_guide_all"
                cleared += "ba_guide_catalog"
                cleared += "github_check"
            }
        }

        return buildString {
            appendLine("scope=$normalizedScope")
            appendLine("message=$message")
            appendLine("cleared=${if (cleared.isEmpty()) "none" else cleared.joinToString(",")}")
        }.trim()
    }
}
