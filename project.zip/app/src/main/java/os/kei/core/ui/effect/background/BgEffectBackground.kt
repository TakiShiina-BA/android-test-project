// Copyright 2026, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

@file:Suppress("FunctionName")

package os.kei.core.ui.effect.background

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import os.kei.ui.page.main.widget.glass.LocalLiquidOverlayHost
import os.kei.ui.page.main.widget.isAppInDarkTheme
import top.yukonga.miuix.kmp.theme.MiuixTheme
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.time.Duration.Companion.milliseconds

private const val DYNAMIC_BACKGROUND_RENDER_SCALE = 0.25f

@Composable
fun BgEffectBackground(
    dynamicBackground: Boolean,
    modifier: Modifier = Modifier,
    bgModifier: Modifier = Modifier,
    effectBackground: Boolean = true,
    isFullSize: Boolean = false,
    alpha: () -> Float = { 1f },
    content: @Composable (BoxScope.() -> Unit),
) {
    val isDark = isAppInDarkTheme()
    val surface = MiuixTheme.colorScheme.surface
    val painter = remember { BgEffectPainter() }

    // A modal presentation covers this background with a blurred, dimmed plate, so the drift behind
    // it cannot be seen — but it can still be *paid for*, because the animation loop invalidates the
    // whole draw tree and every glass surface above re-rasterizes its effect layer on each
    // invalidation. Suspending playback for the duration is the difference between ~7fps and the
    // panel rate on an idle sheet; see [LiquidOverlayHostState.hasPresentation].
    //
    // Only playback stops. `animTime` accrues from real elapsed time and `startAnimation` re-anchors
    // to the value it paused at, so the drift resumes from where it left off rather than jumping.
    val modalPresentationCovers = LocalLiquidOverlayHost.current?.hasPresentation == true
    val playing = dynamicBackground && !modalPresentationCovers

    val preset = remember(isDark) { BgEffectConfig.get(isDark) }

    val colorStage = remember { Animatable(0f) }
    // Keyed on `playing`, not `dynamicBackground`, and this is load-bearing rather than tidiness:
    // `colorStage` is read inside the draw lambda, so a running colour interpolation invalidates draw
    // at spring rate on its own. Pausing the drift loop while leaving this one running would leave the
    // expensive path fully alive for seconds at a time and make the gate above look like it did
    // nothing. Resuming is safe — `targetStage` is recomputed with `floor(colorStage.value) + 1f`,
    // which already tolerates being cancelled mid-spring at a fractional stage.
    LaunchedEffect(playing, preset) {
        if (!playing) return@LaunchedEffect
        val animatesColors = preset.colors1 !== preset.colors2 || preset.colors2 !== preset.colors3
        if (!animatesColors) return@LaunchedEffect

        var targetStage = floor(colorStage.value) + 1f
        while (isActive) {
            delay((preset.colorInterpPeriod * 500).toLong().milliseconds)
            colorStage.animateTo(
                targetValue = targetStage,
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 35f),
            )
            targetStage += 1f
        }
    }

    var targetSize by remember { mutableStateOf(IntSize.Zero) }
    val density = LocalDensity.current
    val renderScale =
        if (dynamicBackground) {
            DYNAMIC_BACKGROUND_RENDER_SCALE
        } else {
            1f
        }
    val renderSize =
        IntSize(
            width = ceil(targetSize.width * renderScale).toInt().coerceAtLeast(0),
            height = ceil(targetSize.height * renderScale).toInt().coerceAtLeast(0),
        )

    Box(
        modifier = modifier.onSizeChanged { targetSize = it },
    ) {
        if (renderSize.width > 0 && renderSize.height > 0) {
            val renderWidthDp = with(density) { renderSize.width.toDp() }
            val renderHeightDp = with(density) { renderSize.height.toDp() }
            val shaderSizeModifier =
                if (dynamicBackground) {
                    // No frame-rate vote here on purpose. A vote governs the whole display, not
                    // just this layer: the High category resolved to 90Hz through the panel's
                    // frameRateCategoryRate and pinned a 120Hz screen there for as long as the
                    // background was visible, and replacing it with an explicit 60 only moved the
                    // ceiling down — a full-screen layer that renders slower than the panel must
                    // not speak for it. Staying silent lets scrolling and pager motion reach the
                    // peak while an idle page still downshifts through LTPO.
                    Modifier
                        .requiredSize(renderWidthDp, renderHeightDp)
                        .graphicsLayer {
                            scaleX = 1f / renderScale
                            scaleY = 1f / renderScale
                            transformOrigin = TransformOrigin(0f, 0f)
                        }
                } else {
                    Modifier.fillMaxSize()
                }
            Spacer(
                modifier = Modifier
                    .then(shaderSizeModifier)
                    .then(bgModifier)
                    .bgEffectDraw(
                        painter = painter,
                        preset = preset,
                        isDark = isDark,
                        surface = surface,
                        effectBackground = effectBackground,
                        isFullSize = isFullSize,
                        playing = playing,
                        colorStage = { colorStage.value },
                        alpha = alpha,
                    ),
            )
        }
        content()
    }
}
